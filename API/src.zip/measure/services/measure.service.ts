import { Repository } from 'typeorm';
import { Observable, from } from 'rxjs';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Measure } from '../../models/entities/Measure';
import { MeasureSpo2 } from '../../models/entities/MeasureSpo2';
import { MeasureEcg } from '../../models/entities/MeasureEcg';
import { MeasureCardipia } from '../../models/entities/MeasureCardipia';
import { MeasureDheart } from '../../models/entities/MeasureDheart';
import { MeasureUrine } from '../../models/entities/MeasureUrine';
import { MeasureSpiro } from '../../models/entities/MeasureSpiro';
import { MeasurePef } from '../../models/entities/MeasurePef';
import { MeasureAsma } from '../../models/entities/MeasureAsma';
import { MeasureCopd6 } from '../../models/entities/MeasureCopd6';
import { MeasureLungMonitor } from '../../models/entities/MeasureLungMonitor';
import { MeasureMicroscope } from '../../models/entities/MeasureMicroscope';
import { MeasureStethoscope } from '../../models/entities/MeasureStethoscope';
import { MeasureCapnography } from '../../models/entities/MeasureCapnography';
import { MeasureTotal } from '../../models/entities/MeasureTotal';
import { Patient } from '../../models/entities/Patient';
import { MeasurePhoto } from '../../models/entities/MeasurePhoto';
import moment from 'moment';

@Injectable()
export class MeasureService {
	constructor(
		@InjectRepository(Patient) private readonly patientRepository: Repository<Patient>,
		@InjectRepository(Measure) private readonly measureRepository: Repository<Measure>,
		@InjectRepository(MeasureSpo2) private readonly measureSpo2Repository: Repository<MeasureSpo2>,
		@InjectRepository(MeasureEcg) private readonly measureEcgRepository: Repository<MeasureEcg>,
		@InjectRepository(MeasureCardipia) private readonly measureCardipiaRepository: Repository<MeasureCardipia>,
		@InjectRepository(MeasureDheart) private readonly measureDheartRepository: Repository<MeasureDheart>,
		@InjectRepository(MeasureUrine) private readonly measureUrineRepository: Repository<MeasureUrine>,
		@InjectRepository(MeasureSpiro) private readonly measureSpiroRepository: Repository<MeasureSpiro>,
		@InjectRepository(MeasurePef) private readonly measurePefRepository: Repository<MeasurePef>,
		@InjectRepository(MeasureAsma) private readonly measureAsmaRepository: Repository<MeasureAsma>,
		@InjectRepository(MeasureCopd6) private readonly measureCopd6Repository: Repository<MeasureCopd6>,
		@InjectRepository(MeasureLungMonitor) private readonly measureLungMonitorRepository: Repository<MeasureLungMonitor>,
		@InjectRepository(MeasureMicroscope) private readonly measureMicroscopeRepository: Repository<MeasureMicroscope>,
		@InjectRepository(MeasureStethoscope) private readonly measureStethoscopeRepository: Repository<MeasureStethoscope>,
		@InjectRepository(MeasureCapnography) private readonly measureCapnographyRepository: Repository<MeasureCapnography>,
		@InjectRepository(MeasureTotal) private readonly measureTotalRepository: Repository<MeasureTotal>,
		@InjectRepository(MeasurePhoto) private readonly measurePhotoRepository: Repository<MeasurePhoto>,
	) {}
	nowDate = new Date();

	// 측정 목록 시작
	// SetMeasureInsert
	addBloodPressure(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const deviceCode = body.deviceCode;
		const deviceId = body.deviceId;
		const directInputYn = body.directInputYn;
		const timezoneOffset = body.timezoneOffset;
		const irregularHeartbeat = body.irregularHeartbeat;
		const autoTimezone = body.autoTimezone;
		const systolic = body.systolic;
		const diastolic = body.diastolic;
		const pulse = body.pulse;
		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.deviceId = deviceId;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.irregularHeartbeat = irregularHeartbeat;
		newMeasure.autoTimezone = autoTimezone;
		newMeasure.measureUnit = 'mmHg';
		newMeasure.measureValue = systolic + '@' + diastolic + '@' + pulse;
		newMeasure.measureType = 'BP';
		const query = this.measureRepository.save(newMeasure);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addBloodSugar(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const bloodSugar = body.bloodSugar;
		const bloodHct = body.bloodHct;
		const measureUnit = body.unit;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = bloodHct == '' ? 'GL' : 'GH';
		newMeasure.measureValue = bloodSugar + '@0@' + bloodHct;
		newMeasure.measureUnit = measureUnit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;
		// newMeasure.deviceId = deviceId
		const query = this.measureRepository.save(newMeasure);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addBloodompositionBM(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const weight = body.weight == undefined ? '' : body.weight;
		const weightUnit = body.weightUnit;
		const height = body.height == undefined ? '' : body.height;
		const heightUnit = body.heightUnit;
		const bmi = body.bmi == undefined ? '' : body.bmi;
		const bodyFat = body.bodyFat == undefined ? '' : body.bodyFat;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'BM';
		newMeasure.measureValue = weight + '@' + height + '@' + bmi + '@' + bodyFat;
		newMeasure.measureUnit = weightUnit + '@' + heightUnit + '@kg/㎡@%';
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;
		// newMeasure.deviceId = deviceId
		const query = this.measureRepository.save(newMeasure);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	addBloodompositionWE(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const weight = body.weight == undefined ? '' : body.weight;
		const weightUnit = body.weightUnit;
		const height = body.height == undefined ? '' : body.height;
		const heightUnit = body.heightUnit;
		const bmi = body.bmi == undefined ? '' : body.bmi;
		const bodyFat = body.bodyFat == undefined ? '' : body.bodyFat;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'WE';
		newMeasure.measureValue = weight + '@' + height + '@' + bmi + '@' + bodyFat;
		newMeasure.measureUnit = weightUnit + '@' + heightUnit + '@kg/㎡@%';
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;
		// newMeasure.deviceId = deviceId
		const query = this.measureRepository.save(newMeasure);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	addBloodomposition(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const weight = body.weight == undefined ? '' : body.weight;
		const weightUnit = body.weightUnit;
		const height = body.height == undefined ? '' : body.height;
		const heightUnit = body.heightUnit;
		const bmi = body.bmi == undefined ? '' : body.bmi;
		const bodyFat = body.bodyFat == undefined ? '' : body.bodyFat;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = '';
		newMeasure.measureValue = weight + '@' + height + '@' + bmi + '@' + bodyFat;
		newMeasure.measureUnit = weightUnit + '@' + heightUnit + '@kg/㎡@%';
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;
		// newMeasure.deviceId = deviceId
		const query = this.measureRepository.save(newMeasure);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addOxygenSaturation(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const spo2 = body.spo2;
		const pulse = body.pulse;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'OX';
		newMeasure.measureValue = spo2 + '@' + pulse + '@';
		newMeasure.measureUnit = '%';
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureOXContinuousInsert
	addContinuousOX(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;
		// const interval = body.interval;
		const oXData = body.oXData;

		const newMeasureSpo2 = new MeasureSpo2();
		// newMeasureSpo2.interval = interval;
		newMeasureSpo2.insungSeq = insungSeq;
		newMeasureSpo2.measureDate = measureDate;
		newMeasureSpo2.timezoneOffset = timezoneOffset;
		newMeasureSpo2.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureSpo2.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureSpo2.deviceCode = deviceCode;
		newMeasureSpo2.autoTimezone = autoTimezone;
		let endValue = '';
		let dataStr = '';
		for (let i = 0; i < oXData.length; i++) {
			const spo2 = oXData[i].s;
			const pulse = oXData[i].p;

			dataStr += '[' + spo2 + ',' + pulse + '],';
			if (i == oXData.length - 1) {
				endValue = spo2 + ',' + pulse;
			}
		}
		newMeasureSpo2.endValue = endValue;
		newMeasureSpo2.data = dataStr.substring(0, dataStr.length - 1);
		newMeasureSpo2.size = oXData.length;

		const query = this.measureSpo2Repository.save(newMeasureSpo2);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert 예제
	addBodyTemperature(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const bodyTemp = body.bodyTemp;
		let unit = body.unit;
		const measurePart = body.measurePart;

		const newMeasure = new Measure();

		if (unit === 'C' || 'F') {
			if (unit === 'C') {
				unit = '℃';
			} else {
				unit = '℉';
			}
		}

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'TE';
		newMeasure.measureValue = bodyTemp;
		newMeasure.measureUnit = unit;
		newMeasure.measureEtc = measurePart;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addCholesterol(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const tc = body.tc == '-1' ? '-' : body.tc.replace('----', '-');
		const tg = body.tg == '-1' ? '-' : body.tg.replace('----', '-');
		const hdl = body.hdl == '-1' ? '-' : body.hdl.replace('----', '-');
		let ldl = body.ldl == '-1' ? '-' : body.ldl.replace('----', '-');
		if (ldl != '') {
			ldl = ldl.trim() == '999' ? '-' : ldl;
		}
		const tcHdlRatio = body.tcHdlRatio == undefined ? '' : body.tcHdlRatio.replace('----', '-');
		const unit = body.unit;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = tcHdlRatio == '' ? 'CH' : 'CA';
		newMeasure.measureValue =
			tcHdlRatio == ''
				? tc + '@' + tg + '@' + hdl + '@' + ldl
				: tc + '@' + tg + '@' + hdl + '@' + ldl + '@' + tcHdlRatio;
		newMeasure.measureUnit = unit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addHba1c(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const hba1c = body.hba1c;
		const unit = body.unit;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'HB';
		newMeasure.measureValue = hba1c;
		newMeasure.measureUnit = unit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addKetone(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const ketone = body.ketone;
		const unit = body.unit;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'KE';
		newMeasure.measureValue = ketone;
		newMeasure.measureUnit = unit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addInr(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const inr = body.inr;
		const pt = body.pt;
		const percentQ = body.percentQ;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'IN';
		newMeasure.measureValue = inr + '@' + pt + '@' + percentQ;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addUrineSpot(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const uacr = body.uacr;
		const albumin = body.albumin;
		const creatinine = body.creatinine;
		const unit = body.unit;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'UA';
		newMeasure.measureValue = uacr + '@' + albumin + '@' + creatinine;
		newMeasure.measureUnit = unit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addUricAcid(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const ua = body.ua;
		const unit = body.unit;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'UC';
		newMeasure.measureValue = ua;
		newMeasure.measureUnit = unit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addBenecheckUrine(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const urine = body.urine;
		const unit = body.unit;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'BU';
		newMeasure.measureValue = urine;
		newMeasure.measureUnit = unit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureUrineInsert
	addUrineStick(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;

		const ob = body.ob;
		const obResult = body.obResult;
		const bil = body.bil;
		const bilResult = body.bilResult;
		const uro = body.uro;
		const uroResult = body.uroResult;
		const ket = body.ket;
		const ketResult = body.ketResult;
		const pro = body.pro;
		const proResult = body.proResult;
		const nit = body.nit;
		const nitResult = body.nitResult;
		const glu = body.glu;
		const gluResult = body.gluResult;
		const ph = body.ph;
		const phResult = body.phResult;
		const leu = body.leu;
		const leuResult = body.leuResult;
		const sg = body.sg;
		const sgResult = body.sgResult;

		const newMeasureUrine = new MeasureUrine();

		newMeasureUrine.insungSeq = insungSeq;
		newMeasureUrine.measureDate = measureDate;
		newMeasureUrine.timezoneOffset = timezoneOffset;
		newMeasureUrine.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureUrine.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureUrine.deviceCode = deviceCode;
		newMeasureUrine.autoTimezone = autoTimezone;

		newMeasureUrine.ob = ob;
		newMeasureUrine.obResult = obResult;
		newMeasureUrine.bil = bil;
		newMeasureUrine.bilResult = bilResult;
		newMeasureUrine.uro = uro;
		newMeasureUrine.uroResult = uroResult;
		newMeasureUrine.ket = ket;
		newMeasureUrine.ketResult = ketResult;
		newMeasureUrine.pro = pro;
		newMeasureUrine.proResult = proResult;
		newMeasureUrine.nit = nit;
		newMeasureUrine.nitResult = nitResult;
		newMeasureUrine.glu = glu;
		newMeasureUrine.gluResult = gluResult;
		newMeasureUrine.ph = ph;
		newMeasureUrine.phResult = phResult;
		newMeasureUrine.leu = leu;
		newMeasureUrine.leuResult = leuResult;
		newMeasureUrine.sg = sg;
		newMeasureUrine.sgResult = sgResult;
		const query = this.measureUrineRepository.save(newMeasureUrine);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureEcgInsert
	addEcg(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;

		const lead1 = body.lead1;
		const lead2 = body.lead2;
		const lead3 = body.lead3;
		const v1 = body.v1;
		const v2 = body.v2;
		const v3 = body.v3;
		const v4 = body.v4;
		const v5 = body.v5;
		const v6 = body.v6;
		const pacePulse = body.pacePulse;
		const diagCode = body.diagCode;
		const pAxis = body.pAxis;
		const ppInterval = body.ppInterval;
		const prInterval = body.prInterval;
		const qrs = body.qrs;
		const qt = body.qt;
		const qtc = body.qtc;
		const rAxis = body.rAxis;
		const rrInterval = body.rrInterval;
		const tAxis = body.tAxis;
		const heartRateInstant = body.heartRateInstant;

		const newMeasureEcg = new MeasureEcg();

		newMeasureEcg.insungSeq = insungSeq;
		newMeasureEcg.measureDate = measureDate;
		newMeasureEcg.timezoneOffset = timezoneOffset;
		newMeasureEcg.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureEcg.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureEcg.deviceCode = deviceCode;
		newMeasureEcg.autoTimezone = autoTimezone;

		newMeasureEcg.lead1 = lead1;
		newMeasureEcg.lead2 = lead2;
		newMeasureEcg.lead3 = lead3;
		newMeasureEcg.v1 = v1;
		newMeasureEcg.v2 = v2;
		newMeasureEcg.v3 = v3;
		newMeasureEcg.v4 = v4;
		newMeasureEcg.v5 = v5;
		newMeasureEcg.v6 = v6;
		newMeasureEcg.pacePulse = pacePulse;
		newMeasureEcg.diagCode = diagCode;
		newMeasureEcg.pAxis = pAxis;
		newMeasureEcg.ppInterval = ppInterval;
		newMeasureEcg.prInterval = prInterval;
		newMeasureEcg.qrs = qrs;
		newMeasureEcg.qt = qt;
		newMeasureEcg.qtc = qtc;
		newMeasureEcg.rAxis = rAxis;
		newMeasureEcg.rrInterval = rrInterval;
		newMeasureEcg.tAxis = tAxis;
		newMeasureEcg.heartRateInstant = heartRateInstant;

		const query = this.measureEcgRepository.save(newMeasureEcg);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureEcgCardipiaInsert
	addEcg2(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;

		const lead1 = body.lead1;
		const lead2 = body.lead2;
		const v1 = body.v1;
		const v2 = body.v2;
		const v3 = body.v3;
		const v4 = body.v4;
		const v5 = body.v5;
		const v6 = body.v6;
		const hr = body.hr;
		const pr = body.pr;
		const qrs = body.qrs;
		const qt = body.qt;
		const qtc = body.qtc;
		const pQrsTQrst = body.pQrsTQrst;
		const qtr = body.qtr;
		const rv5 = body.rv5;
		const sv1 = body.sv1;
		const pa = body.pa;
		const pa_ = body.pa_;
		const qa = body.qa;
		const ra = body.ra;
		const ra_ = body.ra_;
		const sa = body.sa;
		const ta = body.ta;
		const pd = body.pd;
		const qd = body.qd;
		const rd = body.rd;
		const rd_ = body.rd_;
		const pr_ = body.pr_;
		const qt_ = body.qt_;
		const st = body.st;
		const sts = body.sts;
		const tf = body.tf;
		const summary = body.summary;
		const resolution = body.resolution;
		const rr = body.rr;
		const newMeasureCardipia = new MeasureCardipia();

		newMeasureCardipia.insungSeq = insungSeq;
		newMeasureCardipia.measureDate = measureDate;
		newMeasureCardipia.timezoneOffset = timezoneOffset;
		newMeasureCardipia.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureCardipia.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureCardipia.deviceCode = deviceCode;
		newMeasureCardipia.autoTimezone = autoTimezone;
		newMeasureCardipia.rr = rr;
		newMeasureCardipia.lead1 = lead1;
		newMeasureCardipia.lead2 = lead2;
		newMeasureCardipia.v1 = v1;
		newMeasureCardipia.v2 = v2;
		newMeasureCardipia.v3 = v3;
		newMeasureCardipia.v4 = v4;
		newMeasureCardipia.v5 = v5;
		newMeasureCardipia.v6 = v6;
		newMeasureCardipia.hr = hr;
		newMeasureCardipia.pr = pr;
		newMeasureCardipia.qrs = qrs;
		newMeasureCardipia.qt = qt;
		newMeasureCardipia.qtc = qtc;
		newMeasureCardipia.pQrsTQrst = pQrsTQrst;
		newMeasureCardipia.qtr = qtr;
		newMeasureCardipia.rv5 = rv5;
		newMeasureCardipia.sv1 = sv1;
		newMeasureCardipia.pa = pa;
		newMeasureCardipia.pa_ = pa_;
		newMeasureCardipia.qa = qa;
		newMeasureCardipia.ra = ra;
		newMeasureCardipia.ra_ = ra_;
		newMeasureCardipia.sa = sa;
		newMeasureCardipia.ta = ta;
		newMeasureCardipia.pd = pd;
		newMeasureCardipia.qd = qd;
		newMeasureCardipia.rd = rd;
		newMeasureCardipia.rd_ = rd_;
		newMeasureCardipia.pr_ = pr_;
		newMeasureCardipia.qt_ = qt_;
		newMeasureCardipia.st = st;
		newMeasureCardipia.sts = sts;
		newMeasureCardipia.tf = tf;
		newMeasureCardipia.summary = summary;
		newMeasureCardipia.resolution = resolution;
		const query = this.measureCardipiaRepository.save(newMeasureCardipia);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureEcgDHeartInsert
	addEcg3(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;

		const pdfFile = body.pdfFile;
		const bpm = body.bpm;
		const pr = body.pr;
		const qrs = body.qrs;
		const rr = body.rr;
		const qt = body.qt;
		const qtc = body.qtc;

		const newMeasureDheart = new MeasureDheart();

		newMeasureDheart.insungSeq = insungSeq;
		newMeasureDheart.measureDate = measureDate;
		newMeasureDheart.timezoneOffset = timezoneOffset;
		newMeasureDheart.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureDheart.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureDheart.deviceCode = deviceCode;
		newMeasureDheart.autoTimezone = autoTimezone;

		newMeasureDheart.pdfFile = pdfFile;
		newMeasureDheart.bpm = bpm;
		newMeasureDheart.pr = pr;
		newMeasureDheart.qrs = qrs;
		newMeasureDheart.rr = rr;
		newMeasureDheart.qt = qt;
		newMeasureDheart.qtc = qtc;

		const query = this.measureDheartRepository.save(newMeasureDheart);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	//SetMeasureSpiroInsert
	addSpirometer(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;

		const fvc = body.fvc;
		const pef = body.pef;
		const fev1 = body.fev1;
		const fev6 = body.fev6;
		const fev3 = body.fev3;
		const fef2575 = body.fef2575;
		const fef2550 = body.fef2550;
		const fef5075 = body.fef5075;
		const fef25 = body.fef25;
		const fef50 = body.fef50;
		const fef75 = body.fef75;
		const ev = body.ev;
		const fet = body.fet;
		const peft = body.peft;
		const fivc = body.fivc;
		const pif = body.pif;
		const fiv1 = body.fiv1;
		const fit = body.fit;
		const ela = body.ela;

		const height = body.height;

		const newMeasureSpiro = new MeasureSpiro();

		newMeasureSpiro.insungSeq = insungSeq;
		newMeasureSpiro.measureDate = measureDate;
		newMeasureSpiro.timezoneOffset = timezoneOffset;
		newMeasureSpiro.deviceCode = deviceCode;
		newMeasureSpiro.autoTimezone = autoTimezone;

		newMeasureSpiro.fvc = fvc;
		newMeasureSpiro.pef = pef;
		newMeasureSpiro.fev1 = fev1;
		newMeasureSpiro.fev6 = fev6;
		newMeasureSpiro.fev3 = fev3;
		newMeasureSpiro.fef2575 = fef2575;
		newMeasureSpiro.fef2550 = fef2550;
		newMeasureSpiro.fef5075 = fef5075;
		newMeasureSpiro.fef25 = fef25;
		newMeasureSpiro.fef50 = fef50;
		newMeasureSpiro.fef75 = fef75;
		newMeasureSpiro.ev = ev;
		newMeasureSpiro.fet = fet;
		newMeasureSpiro.peft = peft;
		newMeasureSpiro.fivc = fivc;
		newMeasureSpiro.pif = pif;
		newMeasureSpiro.fiv1 = fiv1;
		newMeasureSpiro.fit = fit;
		newMeasureSpiro.ela = ela;
		newMeasureSpiro.height = height;

		const query = this.measureSpiroRepository.save(newMeasureSpiro);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}

	//SetMeasurePEFInsert
	addPef(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;
		const pef = body.pef;
		const fev1 = body.fev1;

		const newMeasurePef = new MeasurePef();

		newMeasurePef.insungSeq = insungSeq;
		newMeasurePef.measureDate = measureDate;
		newMeasurePef.timezoneOffset = timezoneOffset;
		newMeasurePef.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasurePef.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasurePef.deviceCode = deviceCode;
		newMeasurePef.autoTimezone = autoTimezone;

		newMeasurePef.pef = pef;
		newMeasurePef.fev1 = fev1;

		const query = this.measurePefRepository.save(newMeasurePef);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}

	//SetMeasureAsma1Insert
	addAsma1(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;
		const bestPef = body.bestPef;
		const bestFev1 = body.bestFev1;
		const pefPersonalBest = body.pefPersonalBest;
		const fev1PersonalBest = body.fev1PersonalBest;
		const bestPefP = body.bestPefP;
		const bestFev1P = body.bestFev1P;
		const greenZone = body.greenZone;
		const yellowZone = body.yellowZone;
		const orangeZone = body.orangeZone;
		const badTestBestPef = body.badTestBestPef;
		const badTestBestFev1 = body.badTestBestFev1;
		const swVersionNumber = body.swVersionNumber;
		const swNumber = body.swNumber;
		const numberBlows = body.numberBlows;
		const numberGoodBlows = body.numberGoodBlows;
		const accessoryId = body.accessoryId;

		const newMeasureAsma = new MeasureAsma();

		newMeasureAsma.insungSeq = insungSeq;
		newMeasureAsma.measureDate = measureDate;
		newMeasureAsma.timezoneOffset = timezoneOffset;
		newMeasureAsma.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureAsma.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureAsma.deviceCode = deviceCode;
		newMeasureAsma.autoTimezone = autoTimezone;

		newMeasureAsma.bestPef = bestPef;
		newMeasureAsma.bestFev1 = bestFev1;
		newMeasureAsma.pefPersonalBest = pefPersonalBest;
		newMeasureAsma.fev1PersonalBest = fev1PersonalBest;
		newMeasureAsma.bestPefP = bestPefP;
		newMeasureAsma.bestFev1P = bestFev1P;
		newMeasureAsma.greenZone = greenZone;
		newMeasureAsma.yellowZone = yellowZone;
		newMeasureAsma.orangeZone = orangeZone;
		newMeasureAsma.badTestBestPef = badTestBestPef;
		newMeasureAsma.badTestBestFev1 = badTestBestFev1;
		newMeasureAsma.swVersionNumber = swVersionNumber;
		newMeasureAsma.swNumber = swNumber;
		newMeasureAsma.numberBlows = numberBlows;
		newMeasureAsma.numberGoodBlows = numberGoodBlows;
		newMeasureAsma.accessoryId = accessoryId;

		const query = this.measureAsmaRepository.save(newMeasureAsma);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}

	//SetMeasureCOPD6Insert
	addCopd6(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;
		const gender = body.gender;
		const age = body.age;
		const height = body.height;
		const weight = body.weight;
		const tests = body.tests;
		const goodTests = body.goodTests;
		const fev1Within = body.fev1Within;
		const fev6Within = body.fev6Within;
		const fev1Predicted = body.fev1Predicted;
		const fev1Best1 = body.fev1Best1;
		const fev1Best2 = body.fev1Best2;
		const fev1Best3 = body.fev1Best3;
		const fev1MeasuredBest = body.fev1MeasuredBest;
		const fev1PPred = body.fev1PPred;
		const fev6Predicted = body.fev6Predicted;
		const fev6Best1 = body.fev6Best1;
		const fev6Best2 = body.fev6Best2;
		const fev6Best3 = body.fev6Best3;
		const fev6MeasuredBest = body.fev6MeasuredBest;
		const fev6PPred = body.fev6PPred;
		const fev1Fev6Predicted = body.fev1Fev6Predicted;
		const fev1Fev6Best1 = body.fev1Fev6Best1;
		const fev1Fev6Best2 = body.fev1Fev6Best2;
		const fev1Fev6Best3 = body.fev1Fev6Best3;
		const fev1Fev6MeasuredBest = body.fev1Fev6MeasuredBest;
		const fev1Fev6PPred = body.fev1Fev6PPred;
		const greenZone = body.greenZone;
		const yellowZone = body.yellowZone;
		const orangeZone = body.orangeZone;
		const swVersionNumber = body.swVersionNumber;
		const firmwareNumber = body.firmwareNumber;
		const sessionTimeUpdatedFlag = body.sessionTimeUpdatedFlag;
		const accessoryId = body.accessoryId;
		const regression = body.regression;
		const lungAge = body.lungAge;
		const newMMeasureCopd6 = new MeasureCopd6();

		newMMeasureCopd6.regression = regression;
		newMMeasureCopd6.lungAge = lungAge;

		newMMeasureCopd6.insungSeq = insungSeq;
		newMMeasureCopd6.measureDate = measureDate;
		newMMeasureCopd6.timezoneOffset = timezoneOffset;
		newMMeasureCopd6.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMMeasureCopd6.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMMeasureCopd6.deviceCode = deviceCode;
		newMMeasureCopd6.autoTimezone = autoTimezone;

		newMMeasureCopd6.gender = gender;
		newMMeasureCopd6.age = age;
		newMMeasureCopd6.height = height;
		newMMeasureCopd6.weight = weight;
		newMMeasureCopd6.tests = tests;
		newMMeasureCopd6.goodTests = goodTests;
		newMMeasureCopd6.fev1Within = fev1Within;
		newMMeasureCopd6.fev6Within = fev6Within;
		newMMeasureCopd6.fev1Predicted = fev1Predicted;
		newMMeasureCopd6.fev1Best1 = fev1Best1;
		newMMeasureCopd6.fev1Best2 = fev1Best2;
		newMMeasureCopd6.fev1Best3 = fev1Best3;
		newMMeasureCopd6.fev1MeasuredBest = fev1MeasuredBest;
		newMMeasureCopd6.fev1PPred = fev1PPred;
		newMMeasureCopd6.fev6Predicted = fev6Predicted;
		newMMeasureCopd6.fev6Best1 = fev6Best1;
		newMMeasureCopd6.fev6Best2 = fev6Best2;
		newMMeasureCopd6.fev6Best3 = fev6Best3;
		newMMeasureCopd6.fev6MeasuredBest = fev6MeasuredBest;
		newMMeasureCopd6.fev6PPred = fev6PPred;
		newMMeasureCopd6.fev1Fev6Predicted = fev1Fev6Predicted;
		newMMeasureCopd6.fev1Fev6Best1 = fev1Fev6Best1;
		newMMeasureCopd6.fev1Fev6Best2 = fev1Fev6Best2;
		newMMeasureCopd6.fev1Fev6Best3 = fev1Fev6Best3;
		newMMeasureCopd6.fev1Fev6MeasuredBest = fev1Fev6MeasuredBest;
		newMMeasureCopd6.fev1Fev6PPred = fev1Fev6PPred;
		newMMeasureCopd6.greenZone = greenZone;
		newMMeasureCopd6.yellowZone = yellowZone;
		newMMeasureCopd6.orangeZone = orangeZone;
		newMMeasureCopd6.swVersionNumber = swVersionNumber;
		newMMeasureCopd6.firmwareNumber = firmwareNumber;
		newMMeasureCopd6.sessionTimeUpdatedFlag = sessionTimeUpdatedFlag;
		newMMeasureCopd6.accessoryId = accessoryId;

		const query = this.measureCopd6Repository.save(newMMeasureCopd6);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	//SetMeasureLungMonitorInsert
	addLungMonitor(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;
		const bestPef = body.badTestBestPef;
		const bestFev1 = body.badTestBestFev1;
		const bestFev6 = body.badTestBestFev6;
		const bestFev75 = body.bestFev075;
		const bestFev1Fev6 = body.bestFev1Fev6;
		const bestFef2575 = body.badTestBestFev2575;
		const pefPersonalBest = body.pefPersonalBest;
		const fev1PersonalBest = body.fev1PersonalBest;
		const bestPefP = body.bestPefP;
		const bestFev1P = body.bestFev1P;
		const greenZone = body.greenZone;
		const yellowZone = body.yellowZone;
		const orangeZone = body.orangeZone;
		const badTestPef = body.badTestPef;
		const badTestFev1 = body.badTestFev1;
		const badTestFev6 = body.badTestFev6;
		const badTestFev75 = body.badTestFev75;
		const badTestFev2575 = body.badTestFev2575;
		const goodTest = body.goodTest;
		const swVersionNumber = body.swVersionNumber;
		const swNumber = body.swNumber;
		const numberBlows = body.numberBlows;
		const numberGoodBlows = body.numberGoodBlows;
		const accessoryId = body.accessoryId;

		const newMMeasureLungMonitor = new MeasureLungMonitor();

		newMMeasureLungMonitor.insungSeq = insungSeq;
		newMMeasureLungMonitor.measureDate = measureDate;
		newMMeasureLungMonitor.timezoneOffset = timezoneOffset;
		newMMeasureLungMonitor.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMMeasureLungMonitor.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMMeasureLungMonitor.deviceCode = deviceCode;
		newMMeasureLungMonitor.autoTimezone = autoTimezone;

		newMMeasureLungMonitor.bestPef = bestPef;
		newMMeasureLungMonitor.bestFev1 = bestFev1;
		newMMeasureLungMonitor.bestFev6 = bestFev6;
		newMMeasureLungMonitor.bestFev75 = bestFev75;
		newMMeasureLungMonitor.bestFev1Fev6 = bestFev1Fev6;
		newMMeasureLungMonitor.bestFef2575 = bestFef2575;
		newMMeasureLungMonitor.pefPersonalBest = pefPersonalBest;
		newMMeasureLungMonitor.fev1PersonalBest = fev1PersonalBest;
		newMMeasureLungMonitor.bestPefP = bestPefP;
		newMMeasureLungMonitor.bestFev1P = bestFev1P;
		newMMeasureLungMonitor.greenZone = greenZone;
		newMMeasureLungMonitor.yellowZone = yellowZone;
		newMMeasureLungMonitor.orangeZone = orangeZone;
		newMMeasureLungMonitor.badTestPef = badTestPef;
		newMMeasureLungMonitor.badTestFev1 = badTestFev1;
		newMMeasureLungMonitor.badTestFev6 = badTestFev6;
		newMMeasureLungMonitor.badTestFev75 = badTestFev75;
		newMMeasureLungMonitor.badTestFev2575 = badTestFev2575;
		newMMeasureLungMonitor.goodTest = goodTest;
		newMMeasureLungMonitor.swVersionNumber = swVersionNumber;
		newMMeasureLungMonitor.swNumber = swNumber;
		newMMeasureLungMonitor.numberBlows = numberBlows;
		newMMeasureLungMonitor.numberGoodBlows = numberGoodBlows;
		newMMeasureLungMonitor.accessoryId = accessoryId;

		const query = this.measureLungMonitorRepository.save(newMMeasureLungMonitor);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	//SetMeasureMicroscopeInsert
	addMicroscope(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;
		const contents = body.contents;
		const thumbnail = body.thumbnail;

		const newMeasureMicroscope = new MeasureMicroscope();

		newMeasureMicroscope.insungSeq = insungSeq;
		newMeasureMicroscope.measureDate = measureDate;
		newMeasureMicroscope.timezoneOffset = timezoneOffset;
		newMeasureMicroscope.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureMicroscope.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureMicroscope.deviceCode = deviceCode;
		newMeasureMicroscope.autoTimezone = autoTimezone;

		newMeasureMicroscope.contents = contents;
		newMeasureMicroscope.thumbnail = thumbnail;

		const query = this.measureMicroscopeRepository.save(newMeasureMicroscope);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	//SetMeasureStethoscopeInsert
	addStethoscope(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;

		const contents = body.contents;

		const newMeasureStethoscope = new MeasureStethoscope();

		newMeasureStethoscope.insungSeq = insungSeq;
		newMeasureStethoscope.measureDate = measureDate;
		newMeasureStethoscope.timezoneOffset = timezoneOffset;
		newMeasureStethoscope.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureStethoscope.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureStethoscope.deviceCode = deviceCode;
		newMeasureStethoscope.autoTimezone = autoTimezone;

		newMeasureStethoscope.contents = contents;
		const query = this.measureStethoscopeRepository.save(newMeasureStethoscope);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}

	//SetMeasurePhotoInsert
	addPhoto(body: any): Observable<any> {
		console.log(body);
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const deviceId = body.deviceId;
		const autoTimezone = body.autoTimezone;
		const appVersion = body.appVersion;
		const thumbnail = body.thumbnail;
		const contents = body.contents;

		const newMeasurePhoto = new MeasurePhoto();

		newMeasurePhoto.insungSeq = insungSeq;
		newMeasurePhoto.measureDate = measureDate;
		newMeasurePhoto.timezoneOffset = timezoneOffset;
		newMeasurePhoto.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasurePhoto.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasurePhoto.deviceCode = deviceCode;
		newMeasurePhoto.autoTimezone = autoTimezone;
		newMeasurePhoto.contents = contents;
		newMeasurePhoto.deviceId = deviceId;
		newMeasurePhoto.appVersion = appVersion;
		newMeasurePhoto.thumbnail = thumbnail;
		const query = this.measurePhotoRepository.save(newMeasurePhoto);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				console.log(d);
				return data;
			}),
		);
	}
	//SetMeasurePC900BInsert
	addCapnography(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const autoTimezone = body.autoTimezone;
		const interval = body.interval;
		const capnograph = body.capnograph;

		const newMeasureCapnography = new MeasureCapnography();

		newMeasureCapnography.insungSeq = insungSeq;
		newMeasureCapnography.measureDate = measureDate;
		newMeasureCapnography.timezoneOffset = timezoneOffset;
		newMeasureCapnography.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasureCapnography.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasureCapnography.deviceCode = deviceCode;
		newMeasureCapnography.autoTimezone = autoTimezone;

		newMeasureCapnography.interval = interval;
		let endValue = '';
		let dataStr = '';
		for (let i = 0; i < capnograph.length; i++) {
			const s = capnograph[i].s;
			const e = capnograph[i].e;
			const r = capnograph[i].r;
			const p = capnograph[i].p;
			dataStr += '[' + e + ',' + r + ',' + s + ',' + p + '],';
			if (i == capnograph.length - 1) {
				endValue = s + ',' + e + r + ',' + p;
			}
		}
		newMeasureCapnography.endValue = endValue;
		newMeasureCapnography.data = dataStr.substring(0, dataStr.length - 1);

		const query = this.measureCapnographyRepository.save(newMeasureCapnography);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addWaist(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const waistValue = body.waistValue;
		const unit = body.unit;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'WA';
		newMeasure.measureValue = waistValue;
		newMeasure.measureUnit = unit;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// SetMeasureInsert
	addWearable(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureDate = body.measureDate;
		const timezoneOffset = body.timezoneOffset;
		const deviceCode = body.deviceCode;
		const directInputYn = body.directInputYn;
		const autoTimezone = body.autoTimezone;

		const steps = body.steps;

		const newMeasure = new Measure();

		newMeasure.insungSeq = insungSeq;
		newMeasure.measureDate = measureDate;
		newMeasure.timezoneOffset = timezoneOffset;
		newMeasure.measureUtcDt = this.setMeasureUTC(measureDate, timezoneOffset);
		newMeasure.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		newMeasure.measureType = 'WR';
		newMeasure.measureValue = steps;
		newMeasure.deviceCode = deviceCode;
		newMeasure.directInputYn = directInputYn;
		newMeasure.autoTimezone = autoTimezone;

		const query = this.measureRepository.save(newMeasure);
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	// 측정 목록 끝
	getPatientRecent(body: any): Observable<any> {
		// const skip = (body.page_no - 1) * body.page_size;
		// const take = body.page_size;
		const insungSeq = body.insungSeq;
		const measureDevice = body.measureDevice;

		const measureType = [];
		const deviceCode = [];
		for (let i = 0; i < measureDevice.length; i++) {
			measureType.push(measureDevice[i].measureType);
			deviceCode.push(measureDevice[i].deviceCode);
		}
		const subQuery = this.measureTotalRepository
			.createQueryBuilder('measures_total')
			.select(['MAX(measures_total.measure_seq) as measure_seq'])
			.where('measures_total.measure_type IN (:measure_type)', { measure_type: measureType })
			.andWhere('measures_total.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.andWhere('measures_total.device_code IN (:device_code)', { device_code: deviceCode })
			.groupBy('measures_total.measure_type');

		const query = this.measureTotalRepository
			.createQueryBuilder('measures_total')
			.select([
				'measures_total.measure_seq as measureSeq',
				'measures_total.measure_type as measureType',
				'measures_total.device_code as deviceCode',
				'measures_total.measure_utc_dt as measureUtcDt',
				'measures_total.input_utc_dt as inputUtcDt',
				'measures_total.measure_value1 as measureValue1',
				'measures_total.measure_value2 as measureValue2',
				'measures_total.measure_value3 as measureValue3',
				'measures_total.measure_value4 as measureValue4',
				'measures_total.measure_unit1 as measureUnit1',
				'measures_total.measure_unit2 as measureUnit2',
				'measures_total.measure_unit3 as measureUnit3',
				'measures_total.measure_unit4 as measureUnit4',
				'measures_total.measure_unit5 as measureUnit5',
				'measures_total.measure_device as measureDevice',
			])
			.addSelect('ROW_NUMBER () OVER (ORDER BY measures_total.measure_utc_dt desc) as rowNo')
			.where('measures_total.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.andWhere('measures_total.measure_type IN (:measure_type)', { measure_type: measureType })
			.andWhere('measures_total.device_code IN (:device_code)', { device_code: deviceCode })
			.andWhere('measures_total.measure_seq IN (' + subQuery.getQuery() + ')');

		return from(
			Promise.all([query.getRawMany(), query.getCount(), subQuery.getRawMany()]).then((d) => {
				console.log(d[2]);
				for (let i = 0; i < d[0].length; i++) {
					d[0][i]['rowNo'] = '' + (i + 1);
					d[0][i]['measureRow'] = this.SetMeasureValue(d[0][i]);
					d[0][i]['measureUtcDt'] = moment(d[0][i]['measureUtcDt']).format('YYYY-MM-DD HH:mm:ss');
					d[0][i]['inputUtcDt'] = moment(d[0][i]['inputUtcDt']).format('YYYY-MM-DD HH:mm:ss');
					delete d[0][i]['measureValue1'];
					delete d[0][i]['measureValue2'];
					delete d[0][i]['measureValue3'];
					delete d[0][i]['measureValue3'];
					delete d[0][i]['measureValue4'];
					delete d[0][i]['measureUnit1'];
					delete d[0][i]['measureUnit2'];
					delete d[0][i]['measureUnit3'];
					delete d[0][i]['measureUnit4'];
					delete d[0][i]['measureUnit5'];
					delete d[0][i]['measureDevice'];
				}

				const data = {
					statusCode: 200,
					data: d[0],
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	getPatientTable(body: any): Observable<any> {
		const skip = (body.page - 1) * body.pageSize;
		const take = body.pageSize;
		const fromDate = body.fromDate != undefined ? body.fromDate : null;
		const toDate = body.toDate != undefined ? body.toDate : null;
		const insungSeq = body.insungSeq;
		const measureDevice = body.measureDevice;

		const measureType = [];
		const deviceCode = [];
		for (let i = 0; i < measureDevice.length; i++) {
			measureType.push(measureDevice[i].measureType);
			deviceCode.push(measureDevice[i].deviceCode);
		}
		const query = this.measureTotalRepository
			.createQueryBuilder('measures_total')
			.select([
				'measures_total.measure_seq as measureSeq',
				'measures_total.measure_type as measureType',
				'measures_total.device_code as deviceCode',
				'measures_total.measure_utc_dt as measureUtcDt',
				'measures_total.input_utc_dt as inputUtcDt',
				'measures_total.measure_value1 as measureValue1',
				'measures_total.measure_value2 as measureValue2',
				'measures_total.measure_value3 as measureValue3',
				'measures_total.measure_value4 as measureValue4',
				'measures_total.measure_unit1 as measureUnit1',
				'measures_total.measure_unit2 as measureUnit2',
				'measures_total.measure_unit3 as measureUnit3',
				'measures_total.measure_unit4 as measureUnit4',
				'measures_total.measure_unit5 as measureUnit5',
				'measures_total.measure_device as measureDevice',
			])
			.addSelect('ROW_NUMBER () OVER (ORDER BY measures_total.measure_utc_dt desc) as row_num')
			.where('measures_total.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.andWhere('measures_total.measure_type IN (:measure_type)', { measure_type: measureType })
			.andWhere('measures_total.device_code IN (:device_code)', { device_code: deviceCode });

		if (fromDate != null && toDate != null) {
			query
				.andWhere('measures_total.measure_utc_dt >= :fromDate')
				.andWhere('measures_total.measure_utc_dt <= :toDate')
				.setParameter('fromDate', moment(fromDate).format('YYYY-MM-DD'))
				.setParameter('toDate', moment(toDate).format('YYYY-MM-DD'));
		}
		return from(
			Promise.all([query.offset(skip).limit(take).getRawMany(), query.getCount()]).then((d) => {
				for (let i = 0; i < d[0].length; i++) {
					d[0][i]['rowNo'] = '' + (i + 1);
					d[0][i]['measureRow'] = this.SetMeasureValue(d[0][i]);
					d[0][i]['measureUtcDt'] = moment(d[0][i]['measureUtcDt']).format('YYYY-MM-DD HH:mm:ss');
					d[0][i]['inputUtcDt'] = moment(d[0][i]['inputUtcDt']).format('YYYY-MM-DD HH:mm:ss');
					delete d[0][i]['measureValue1'];
					delete d[0][i]['measureValue2'];
					delete d[0][i]['measureValue3'];
					delete d[0][i]['measureValue3'];
					delete d[0][i]['measureValue4'];
					delete d[0][i]['measureUnit1'];
					delete d[0][i]['measureUnit2'];
					delete d[0][i]['measureUnit3'];
					delete d[0][i]['measureUnit4'];
					delete d[0][i]['measureUnit5'];
					delete d[0][i]['measureDevice'];
				}
				const data = {
					statusCode: 200,
					data: {
						totalCount: d[1],
						measureList: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	setMeasureUTC(measureDate, timezoneOffset): any {
		const measureUTC =
			measureDate.substr(0, 4) +
			'-' +
			measureDate.substr(4, 2) +
			'-' +
			measureDate.substr(6, 2) +
			' ' +
			measureDate.substr(8, 2) +
			':' +
			measureDate.substr(10, 2) +
			':' +
			measureDate.substr(12, 2);
		const date = new Date(measureUTC);
		return new Date(date.getTime() + timezoneOffset * 60000);
	}
	SetMeasureValue(d): any {
		let teStatus = 0;
		let row;
		if (d.measureType == 'TE') {
			if (d.measureUnit1 == '℃') {
				teStatus = this.GetMeasureValueStatus('TE', '', d.measureValue1);
			}
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: this.GetMeasureValueStatusColor(teStatus),
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'KE') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'HB') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'BU') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'PH') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: '',
					measureValue: d.measureValue2,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'TC') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (
			d.measureType == 'EC' ||
			d.measureType == 'PF' ||
			d.measureType == 'UR' ||
			d.measureType == 'AS' ||
			d.measureType == 'CO' ||
			d.measureType == 'LM' ||
			d.measureType == 'OT'
		) {
			if (d.measureType == 'EC') {
				row = [
					{
						measureItem: 'bent rate',
						measureValue: d.measureValue1,
						measureUnit: 'bpm',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'pr interval',
						measureValue: d.measureValue2,
						measureUnit: 'ms',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'qrs interval',
						measureValue: d.measureValue3,
						measureUnit: 'ms',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			} else if (d.measureType == 'PF') {
				if (d.measureDevice.toLowerCase() == 'pf200' || d.measureDevice.toLowerCase() == 'asma-1') {
					row = [
						{
							measureItem: 'pef',
							measureValue: d.measureValue1,
							measureUnit: 'L/min',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'fev1',
							measureValue: d.measureValue2,
							measureUnit: 'L',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'qrs interval',
							measureValue: d.measureValue3,
							measureUnit: 'ms',
							measureColor: '',
							measureStatus: teStatus,
						},
					];
				} else {
					row = [
						{
							measureItem: 'fvc',
							measureValue: d.measureValue1,
							measureUnit: 'L',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'fev1',
							measureValue: d.measureValue2,
							measureUnit: 'L',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'fev1/fvc',
							measureValue: d.measureValue3,
							measureUnit: '%',
							measureColor: '',
							measureStatus: teStatus,
						},
					];
				}
			} else if (d.measureType == 'AS') {
				row = [
					{
						measureItem: 'pef',
						measureValue: d.measureValue1,
						measureUnit: 'L/min',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev1',
						measureValue: d.measureValue2,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			} else if (d.measureType == 'CO') {
				row = [
					{
						measureItem: 'fev1',
						measureValue: d.measureValue1,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev6',
						measureValue: d.measureValue2,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev1/fev6',
						measureValue: d.measureValue3,
						measureUnit: '%',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			} else if (d.measureType == 'LM') {
				row = [
					{
						measureItem: 'fev1',
						measureValue: d.measureValue1,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev1%',
						measureValue: d.measureValue2,
						measureUnit: '%',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev6',
						measureValue: d.measureValue3,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			}
		} else if (d.measureType == 'BP') {
			const sys = this.GetMeasureValueStatus('BP', 'sys', d.measureValue1);
			const dia = this.GetMeasureValueStatus('BP', 'dia', d.measureValue2);
			const pulse = this.GetMeasureValueStatus('PU', '', d.measureValue3);
			let bpColor = '';
			if (sys >= dia) bpColor = this.GetMeasureValueStatusColor(sys);
			else bpColor = this.GetMeasureValueStatusColor(dia);

			const pulseColor = this.GetMeasureValueStatusColor(pulse);

			row = [
				{
					measureItem: 'systolic',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: bpColor,
					measureStatus: teStatus,
				},
				{
					measureItem: 'diastolic',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit1,
					measureColor: bpColor,
					measureStatus: teStatus,
				},
				{
					measureItem: 'pulse',
					measureValue: d.measureValue3,
					measureUnit: 'bpm',
					measureColor: pulseColor,
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'GL' || d.measureType == 'GH') {
			let timeFlag = d.measurevalue2;
			if (timeFlag == '1') timeFlag = 'before meal';
			else if (timeFlag == '2') timeFlag = 'after meal';
			else timeFlag = 'others';

			let glStatus = 0;

			if (d.measureUnit1 == 'mg/dL') {
				glStatus = this.GetMeasureValueStatus('GL', d.measureValue2, d.measureValue1);
			}
			row = [
				{
					measureItem: 'glucose',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: this.GetMeasureValueStatusColor(glStatus),
					measureStatus: teStatus,
				},
			];
			if (d.measureType == 'GH') {
				row.push({
					measureItem: 'hct',
					measureValue: d.measureValue3,
					measureUnit: '%',
					measureColor: '',
					measureStatus: teStatus,
				});
			}
		} else if (d.measureType == 'CH' || d.measureType == 'CA') {
			row = [
				{
					measureItem: 'tc',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'tg',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'hdl',
					measureValue: d.measureValue3,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'ldl',
					measureValue: d.measureValue4,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'tc / hdl',
					measureValue: d.measureValue5,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'WE') {
			row = [
				{
					measureItem: 'weight',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'height',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit2,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bmi',
					measureValue: d.measureValue3,
					measureUnit: d.measureUnit3,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bodyfat',
					measureValue: d.measureValue4,
					measureUnit: d.measureUnit4,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'BM') {
			row = [
				{
					measureItem: 'weight',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'height',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit2,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bmi',
					measureValue: d.measureValue3,
					measureUnit: d.measureUnit3,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bodyfat',
					measureValue: d.measureValue4,
					measureUnit: d.measureUnit4,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'OX') {
			const puStatus = this.GetMeasureValueStatus('PU', '', d.measureValue2);
			row = [
				{
					measureItem: 'spo2',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'pulse',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit2,
					measureColor: this.GetMeasureValueStatusColor(puStatus),
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'IN') {
			row = [
				{
					measureItem: 'inr',
					measureValue: d.measureValue1,
					measureUnit: 'INR',
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'pt',
					measureValue: d.measureValue2,
					measureUnit: 'sec.',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
			if (d.measureValue3 != '' && d.measureDevice == 'CoaguChek XS') {
				row.push({
					measureItem: 'percentq',
					measureValue: d.measureValue3,
					measureUnit: '%Q',
					measureColor: '',
					measureStatus: teStatus,
				});
			}
		} else if (d.measureType == 'MS') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'ME') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'ST') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'UC') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'CG') {
			row = [
				{
					measureItem: 'etco2',
					measureValue: d.measureValue1,
					measureUnit: '%',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		}
		return row;
	}
	GetMeasureValueStatus(measureType, subType, measureValue): any {
		let rtnValue = 0;
		const fValue = parseFloat(measureValue);

		if (measureType == 'BP') {
			if (subType == 'sys') {
				if (fValue < 120) rtnValue = 0;
				else if (fValue >= 120 && fValue <= 139) rtnValue = 1;
				else if (fValue >= 140 && fValue <= 159) rtnValue = 2;
				else if (fValue >= 160) rtnValue = 3;
			}

			if (subType == 'dia') {
				if (fValue < 80) rtnValue = 0;
				else if (fValue >= 80 && fValue <= 89) rtnValue = 1;
				else if (fValue >= 90 && fValue < 99) rtnValue = 2;
				else if (fValue >= 100) rtnValue = 3;
			}
		} else if (measureType == 'PU') {
			if (fValue >= 100) rtnValue = 3;
			else rtnValue = 0;
		} else if (measureType == 'GL') {
			if (subType == '0') {
				if (fValue < 100) rtnValue = 0;
				else if (fValue >= 100 && fValue <= 125) rtnValue = 1;
				else if (fValue > 125) rtnValue = 3;
			} else if (subType == '1') {
				if (fValue < 140) rtnValue = 0;
				else if (fValue >= 140 && fValue < 200) rtnValue = 1;
				else if (fValue >= 200) rtnValue = 3;
			} else if (subType == '2') {
				rtnValue = 0;
			}
		} else if (measureType == 'TE') {
			if (fValue >= 36 && fValue <= 37.9) rtnValue = 0;
			else if (fValue >= 38 && fValue < 39.9) rtnValue = 1;
			else if (fValue >= 40 && fValue <= 42) rtnValue = 2;
			else if (fValue > 42) rtnValue = 3;
		}

		return rtnValue;
	}
	GetMeasureValueStatusColor(grade): any {
		let rtnValue = '454545';
		switch (grade) {
			case 0:
				rtnValue = '454545';
				break;
			case 1:
				rtnValue = 'ffc500';
				break;
			case 2:
				rtnValue = 'c06100';
				break;
			case 3:
				rtnValue = 'f10101';
				break;
			default:
				rtnValue = '454545';
				break;
		}
		return rtnValue;
	}
}
