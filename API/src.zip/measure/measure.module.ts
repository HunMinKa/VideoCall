import { MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { MeasureService } from './services/measure.service';
import { MeasureController } from './controller/measure.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { Measure } from '../models/entities/Measure';
import { MeasureSpo2 } from '../models/entities/MeasureSpo2';
import { MeasureEcg } from '../models/entities/MeasureEcg';
import { MeasureCardipia } from '../models/entities/MeasureCardipia';
import { MeasureDheart } from '../models/entities/MeasureDheart';
import { MeasureUrine } from '../models/entities/MeasureUrine';
import { MeasureSpiro } from '../models/entities/MeasureSpiro';
import { MeasurePef } from '../models/entities/MeasurePef';
import { MeasureAsma } from '../models/entities/MeasureAsma';
import { MeasureCopd6 } from '../models/entities/MeasureCopd6';
import { MeasureLungMonitor } from '../models/entities/MeasureLungMonitor';
import { MeasureMicroscope } from '../models/entities/MeasureMicroscope';
import { MeasureStethoscope } from '../models/entities/MeasureStethoscope';
import { MeasureCapnography } from '../models/entities/MeasureCapnography';
import { MeasureTotal } from '../models/entities/MeasureTotal';
import { Patient } from '../models/entities/Patient';
import { DecrtpytAESMiddleware } from 'src/middleware/enc.middleware';
import { ApiLogHistory } from '../models/entities/ApiLogHistory';
import { MeasurePhoto } from '../models/entities/MeasurePhoto';
@Module({
	imports: [
		TypeOrmModule.forFeature([
			Patient,
			Measure,
			MeasureTotal,
			MeasureSpo2,
			MeasureEcg,
			MeasureCardipia,
			MeasureDheart,
			MeasureUrine,
			MeasureSpiro,
			MeasurePef,
			MeasureAsma,
			MeasureCopd6,
			MeasureLungMonitor,
			MeasureMicroscope,
			MeasureStethoscope,
			MeasureCapnography,
			ApiLogHistory,
			MeasurePhoto,
		]),
		AuthModule,
	],
	providers: [MeasureService],
	controllers: [MeasureController],
	exports: [MeasureService],
})
export class MeasureModule implements NestModule {
	configure(consumer: MiddlewareConsumer) {
		consumer.apply(DecrtpytAESMiddleware).forRoutes({ path: 'measure/*', method: RequestMethod.POST });
	}
}
