import {
	Controller,
	HttpStatus,
	Res,
	Req,
	Post,
	Session,
	UseInterceptors,
	Get,
	Param,
	Query,
	UploadedFile,
} from '@nestjs/common';
import { MeasureService } from '../services/measure.service';
import { from, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ConfigService } from '@nestjs/config';
import { Response, Request } from 'express';
import { ApiForbiddenResponse, ApiCreatedResponse, ApiTags, ApiBody, ApiHeader } from '@nestjs/swagger';
import * as crypto from 'crypto-browserify';
import { Base64 } from 'js-base64';
import * as pkcs7 from 'pkcs7';
import { Encryptnterceptor } from 'src/Interceptors/enc.Interceptors';
import { FilesInterceptor } from '@nestjs/platform-express';
import { multerOptions } from 'src/fileUploader/multerOptions';
import * as fs from 'fs';
import * as path from 'path';
import * as apiBody from '../../models/interface/MeasureAPI';

@ApiTags('Measure')
@Controller('measure')
@UseInterceptors(Encryptnterceptor)
export class MeasureController {
	constructor(private measureService: MeasureService, private configService: ConfigService) {}
	public currentDate = new Date();

	@Get('/image')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getImage(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
		@Query('fileName') fileName: string,
	): any {
		const file = fs.readFileSync(path.join(__dirname, '../../fileUploader/images/' + fileName), 'utf-8');
		const data = file;

		return data;
	}

	@Post('/photo1')
	@ApiBody({ type: apiBody.Photo })
	@UseInterceptors(FilesInterceptor('file', null, multerOptions))
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addPhoto1(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
		@Query('fileName') fileName: string,
	): Observable<any> {
		const file = fs.readFileSync(path.join(__dirname, '../../fileUploader/images/' + fileName), 'utf-8');
		console.log(file);
		return from(
			Promise.all(file).then((d) => {
				const data = {
					statusCode: 200,
					data: file,
					message: 'success',
				};

				return data;
			}),
		);
	}

	@Post('/blood-pressure')
	@ApiBody({ type: apiBody.BloodPressure })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addBloodPressure(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addBloodPressure(req.body);
	}

	@Post('/blood-sugar')
	@ApiBody({ type: apiBody.BloodSugar })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addBloodSugar(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addBloodSugar(req.body);
	}

	@Post('/body-composition')
	@ApiBody({ type: apiBody.BodyComposition })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addBloodomposition(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addBloodomposition(req.body);
	}

	@Post('/body-mass-index')
	@ApiBody({ type: apiBody.BodyComposition })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addBloodompositionBM(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addBloodompositionBM(req.body);
	}
	@Post('/scale')
	@ApiBody({ type: apiBody.BodyComposition })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addBloodompositionWE(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addBloodompositionWE(req.body);
	}
	@Post('/spo2')
	@ApiBody({ type: apiBody.OxygenSaturation })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addOxygenSaturation(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addOxygenSaturation(req.body);
	}

	@Post('/spo2/continuous')
	@ApiBody({ type: apiBody.ContinuousOX })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addContinuousOX(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addContinuousOX(req.body);
	}

	@Post('/body-temperature')
	@ApiBody({ type: apiBody.BodyTemperature })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addBodyTemperature(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addBodyTemperature(req.body);
	}

	@Post('/cholesterol')
	@ApiBody({ type: apiBody.Cholesterol })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addCholesterol(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addCholesterol(req.body);
	}

	@Post('/hba1c')
	@ApiBody({ type: apiBody.Hba1c })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addHba1c(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addHba1c(req.body);
	}

	@Post('/ketone')
	@ApiBody({ type: apiBody.Ketone })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addKetone(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addKetone(req.body);
	}

	@Post('/inr')
	@ApiBody({ type: apiBody.Inr })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addInr(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addInr(req.body);
	}

	@Post('/urinalysis/spot')
	@ApiBody({ type: apiBody.UrineSpot })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addUrineSpot(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addUrineSpot(req.body);
	}

	@Post('/urinalysis/uric-acid')
	@ApiBody({ type: apiBody.UricAcid })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addUricAcid(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addUricAcid(req.body);
	}

	@Post('/urinalysis/benecheck')
	@ApiBody({ type: apiBody.BenecheckUrin })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addBenecheckUrine(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addBenecheckUrine(req.body);
	}
	@Post('/urinalysis/stick')
	@ApiBody({ type: apiBody.UrineStick })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addUrineStick(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addUrineStick(req.body);
	}

	@Post('/ecg')
	@ApiBody({ type: apiBody.Ecg })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addEcg(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addEcg(req.body);
	}

	@Post('/ecg/cardipia')
	@ApiBody({ type: apiBody.Ecg2 })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addEcg2(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addEcg2(req.body);
	}

	@Post('/ecg/d-heart')
	@ApiBody({ type: apiBody.Ecg3 })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addEcg3(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addEcg3(req.body);
	}

	@Post('/spirometer')
	@ApiBody({ type: apiBody.Spirometer })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addSpirometer(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addSpirometer(req.body);
	}

	@Post('/spirometer/pef')
	@ApiBody({ type: apiBody.Pef })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addPef(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addPef(req.body);
	}

	@Post('/spirometer/asma1')
	@ApiBody({ type: apiBody.Asma1 })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addAsma1(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addAsma1(req.body);
	}

	@Post('/spirometer/copd6')
	@ApiBody({ type: apiBody.Copd6 })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addCopd6(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addCopd6(req.body);
	}

	@Post('/spirometer/lung-monitor')
	@ApiBody({ type: apiBody.LungMonitor })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addLungMonitor(
		@Req() req: Request,
		@Res() res: Response,

		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addLungMonitor(req.body);
	}

	@Post('/microscope')
	@ApiBody({ type: apiBody.Microscope })
	@UseInterceptors(FilesInterceptor('file', null, multerOptions))
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addMicroscope(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		const symKey = req['symKey'];

		req.body = this.decryptAES(symKey, req.body.fileInfo);
		fs.readFile(path.join(__dirname, '../../fileUploader/images/' + req.body.contents), 'utf8', (error, d) => {
			fs.writeFileSync(
				path.join(__dirname, '../../fileUploader/images/' + req.body.contents),
				this.decryptAES2(symKey, d),
			);
		});

		fs.readFile(path.join(__dirname, '../../fileUploader/images/' + req.body.thumbnail), 'utf8', (error, d) => {
			fs.writeFileSync(
				path.join(__dirname, '../../fileUploader/images/' + req.body.thumbnail),
				this.decryptAES2(symKey, d),
			);
		});
		return this.measureService.addMicroscope(req.body);
	}

	@Post('/photo')
	@ApiBody({ type: apiBody.Photo })
	@UseInterceptors(FilesInterceptor('file', null, multerOptions))
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addPhoto(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		const symKey = req['symKey'];
		req.body = this.decryptAES(symKey, req.body.fileInfo);

		fs.readFile(path.join(__dirname, '../../fileUploader/images/' + req.body.contents), 'utf8', (error, d) => {
			fs.writeFileSync(
				path.join(__dirname, '../../fileUploader/images/' + req.body.contents),
				this.decryptAES2(symKey, d),
			);
		});

		fs.readFile(path.join(__dirname, '../../fileUploader/images/' + req.body.thumbnail), 'utf8', (error, d) => {
			fs.writeFileSync(
				path.join(__dirname, '../../fileUploader/images/' + req.body.thumbnail),
				this.decryptAES2(symKey, d),
			);
		});
		return this.measureService.addPhoto(req.body);
	}

	@UseInterceptors(FilesInterceptor('file', null, multerOptions))
	@Post('/stethoscope')
	@ApiBody({ type: apiBody.Stethoscope })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addStethoscope(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
		@UploadedFile() file,
	): Observable<unknown> {
		const symKey = req['symKey'];

		req.body = this.decryptAES(symKey, req.body.fileInfo);
		fs.readFile(path.join(__dirname, '../../fileUploader/images/' + req.body.contents), 'utf8', (error, d) => {
			fs.writeFileSync(
				path.join(__dirname, '../../fileUploader/images/' + req.body.contents),
				this.decryptAES2(symKey, d),
			);
		});

		return this.measureService.addStethoscope(req.body);
	}

	@Post('/capnography')
	@ApiBody({ type: apiBody.Capnography })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addCapnography(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.addCapnography(req.body);
	}

	@Post('/waist')
	@ApiBody({ type: apiBody.Waist })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addWaist(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addWaist(req.body);
	}

	@Post('/steps')
	@ApiBody({ type: apiBody.Wearable })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addWearable(@Req() req: Request, @Res() res: Response, @Session() session: Record<string, any>): Observable<unknown> {
		return this.measureService.addWearable(req.body);
	}

	@Post('/table')
	@ApiBody({ type: apiBody.Table })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getPatientTable(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.getPatientTable(req.body);
	}

	@Post('/recent')
	@ApiBody({ type: apiBody.Recent })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getPatientRecent(
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.measureService.getPatientRecent(req.body);
	}

	decryptAES2(symKey: any, text: any): string {
		const key = Base64.atob(symKey);
		const array = Uint8Array.from(key, (b) => b.charCodeAt(0));
		const iv = crypto.createHash('md5').update(array).digest();

		const decipher = crypto.createDecipheriv('aes-256-cbc', array, iv);

		decipher.setAutoPadding(false);
		let decrypted = decipher.update(text, 'base64', 'base64');
		decrypted += decipher.final('base64');

		return decrypted;
	}

	decryptAES(symKey: any, text: any): string {
		const key = Base64.atob(symKey);
		const array = Uint8Array.from(key, (b) => b.charCodeAt(0));
		const iv = crypto.createHash('md5').update(array).digest();

		const decipher = crypto.createDecipheriv('aes-256-cbc', array, iv);

		decipher.setAutoPadding(false);
		let decrypted = decipher.update(text, 'base64', 'utf8');
		decrypted += decipher.final('utf8');
		return this.pkcs7Unpad(decrypted);
	}

	pkcs7Unpad(params: any): string {
		const buffer = Buffer.from(params, 'utf8');
		const bytes = new Uint8Array(buffer.length);
		let i = buffer.length;
		while (i--) {
			bytes[i] = buffer[i];
		}
		const result = Buffer.from(pkcs7.unpad(bytes));
		return result.toString('utf-8') == '' ? '' : JSON.parse(result.toString('utf-8'));
	}
}
