import { Module } from '@nestjs/common';
import { DoctorService } from './services/doctor.service';
import { DoctorController } from './controller/doctor.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { Patient } from '../models/entities/Patient';
import { Appointment } from '../models/entities/Appointment';
import { Message } from '../models/entities/Message';
import { Doctor } from '../models/entities/Doctor';
import { DoctorPatientRelation } from '../models/entities/DoctorPatientRelation';
import { MeasureTotal } from '../models/entities/MeasureTotal';
import { VideoConsultationMaster } from '../models/entities/VideoConsultationMaster';
import { VideoConsultationHistory } from '../models/entities/VideoConsultationHistory';
import { DoctorSubscription } from '../models/entities/DoctorSubscription';
import { Assessment } from '../models/entities/Assessment';
@Module({
	imports: [
		TypeOrmModule.forFeature([
			Patient,
			DoctorPatientRelation,
			Appointment,
			MeasureTotal,
			Doctor,
			Message,
			VideoConsultationMaster,
			VideoConsultationHistory,
			DoctorSubscription,
			Assessment,
		]),
		AuthModule,
	],
	providers: [DoctorService],
	controllers: [DoctorController],
	exports: [DoctorService],
})
export class DoctorModule {}
