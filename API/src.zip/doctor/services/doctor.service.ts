import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Patient } from '../../models/entities/Patient';
import { Appointment } from '../../models/entities/Appointment';
import { MeasureTotal } from '../../models/entities/MeasureTotal';
import { Message } from '../../models/entities/Message';
import { Doctor } from '../../models/entities/Doctor';
import { PatientI } from '../../models/interface/Patient.interface';
import { VideoConsultationMaster } from '../../models/entities/VideoConsultationMaster';
import { VideoConsultationHistory } from '../../models/entities/VideoConsultationHistory';
import { Assessment } from '../../models/entities/Assessment';
import { Repository } from 'typeorm';
import { Observable, from } from 'rxjs';
import * as admin from 'firebase-admin';
import serviceAccount from '../../hicare-c18c9-firebase-adminsdk-wmvwh-3a9d6cbe99.json';
import { DoctorSubscription } from '../../models/entities/DoctorSubscription';
import { DoctorI } from 'src/models/interface/Doctor.interface';
import NodeRSA from 'node-rsa';
import { switchMap, map } from 'rxjs/operators';
import { AuthService } from 'src/auth/services/auth.service';
import * as _ from 'lodash';
@Injectable()
export class DoctorService {
	constructor(
		@InjectRepository(Patient) private readonly patientRepository: Repository<PatientI>,
		@InjectRepository(Appointment) private readonly appointmentRepository: Repository<Appointment>,
		@InjectRepository(MeasureTotal) private readonly measureTotalRepository: Repository<MeasureTotal>,
		@InjectRepository(Doctor) private readonly doctorRepository: Repository<Doctor>,
		@InjectRepository(Message) private readonly messageRepository: Repository<Message>,
		@InjectRepository(VideoConsultationMaster) private readonly videoRepository: Repository<VideoConsultationMaster>,
		@InjectRepository(Assessment) private readonly assessmentRepository: Repository<Assessment>,
		@InjectRepository(VideoConsultationHistory)
		private readonly videoHistoryRepository: Repository<VideoConsultationHistory>,
		@InjectRepository(DoctorSubscription) private readonly doctorSubscriptionRepository: Repository<DoctorSubscription>,
		private configService: ConfigService,
		private authService: AuthService,
	) {}

	loginDoctor(doctor: DoctorI): Observable<string> {
		const encryptKey = new NodeRSA(this.configService.get('PUBLIC_KEY'));
		const encrypted = encryptKey.encrypt(doctor, 'base64');

		const decryptKey = new NodeRSA(this.configService.get('PRIVATE_KEY'));
		const decrypted = JSON.parse(decryptKey.decrypt(encrypted, 'utf8'));

		return this.validateDoctor(decrypted.login_id, decrypted.password).pipe(
			switchMap((doctor: DoctorI) => {
				if (doctor) {
					delete doctor.password;
					return this.authService.generateJWT(doctor).pipe(map((jwt: string) => jwt));
				} else {
					return 'Wrong Credentials';
				}
			}),
		);
	}

	validateDoctor(login_id: string, password: string): Observable<any> {
		return from(
			this.doctorRepository.findOne({
				where: [{ loginId: login_id }],
			}),
		).pipe(
			switchMap((doctor: DoctorI) =>
				this.authService.comparePasswords(password, doctor.password).pipe(
					map((match: any) => {
						if (match) {
							delete doctor.password;
							const { ...result } = doctor;
							return result;
						} else {
							throw Error;
						}
					}),
				),
			),
		);
	}

	getPatient(body: any): Observable<any> {
		const insungSeq = body.insung_seq;

		return from(
			this.patientRepository
				.createQueryBuilder('patient')
				.select([
					'patient.firstName as firstName',
					'patient.middleName as middleName',
					'patient.lastName as lastName',
					'patient.gender as gender',
					'patient.dob as dob',
					'patient.loginId as loginId',
					'"routine" AS status',
					'"" AS diagnosis',
				])
				.where('patient.insungSeq = :insungSeq', { insungSeq })
				.getRawMany(),
		);
	}
	getPatientList(doctor: any): Observable<any> {
		const doctorSeq = doctor.doctorSeq;

		const query2 = this.measureTotalRepository
			.createQueryBuilder('measures_total')
			.select([
				'measures_total.insung_seq as insungSeq',
				'measures_total.measure_seq as measureSeq',
				'measures_total.measure_type as measureType',
				'measures_total.device_code as deviceCode',
				'measures_total.measure_utc_dt as measureUtcDt',
				'measures_total.input_utc_dt as inputUtcDt',
				'measures_total.direct_input_yn as directInputYn',
				'measures_total.measure_value1 as measureValue1',
				'measures_total.measure_value2 as measureValue2',
				'measures_total.measure_value3 as measureValue3',
				'measures_total.measure_value4 as measureValue4',
				'measures_total.measure_unit1 as measureUnit1',
				'measures_total.measure_unit2 as measureUnit2',
				'measures_total.measure_unit3 as measureUnit3',
				'measures_total.measure_unit4 as measureUnit4',
				'measures_total.measure_unit5 as measureUnit5',
				'measures_total.measure_device as measureDevice',
			])
			.addSelect('ROW_NUMBER () OVER (ORDER BY measures_total.measure_utc_dt desc) as rowNo')
			.leftJoin(
				'doctor_patient_relation',
				'doctor_patient_relation',
				'measures_total.insung_seq = doctor_patient_relation.insung_seq',
			)
			.where('doctor_patient_relation.doctor_seq = :doctor_seq', { doctor_seq: doctorSeq });

		const query = this.patientRepository
			.createQueryBuilder('patient')
			.select([
				'patient.firstName as firstName',
				'patient.insung_seq as insungSeq',
				'patient.middleName as middleName',
				'patient.lastName as lastName',
				'patient.gender as gender',
				'patient.dob as dob',
				'patient.loginId as loginId',
				'"routine" as status',
				'doctorPatientRelations.doctor_seq as doctor_seq',
			])

			.addSelect('ROW_NUMBER () OVER (ORDER BY patient.input_utc_dt desc) as row_num')
			.leftJoin('patient.doctorPatientRelations', 'doctorPatientRelations')
			.where('doctorPatientRelations.doctor_seq = :doctor_seq', { doctor_seq: doctorSeq });

		return from(
			Promise.all([query.getRawMany(), query.getCount(), query2.getRawMany()]).then((d) => {
				if (d[2].length == 0) {
				} else {
					for (let i = 0; i < d[1]; i++) {
						const measureDt = _.find(d[2], { insungSeq: d[0][i]['insungSeq'] });
						const dt = d[0][i];
						dt['name'] =
							(dt['firstName'] === null ? '' : dt['firstName']) +
							(dt['middleName'] === null ? '' : ' ' + dt['middleName']) +
							(dt['lastName'] === null ? '' : ' ' + dt['lastName']);
						dt['gender'] = d[0][i]['gender'] === '4qQRuXdxtOOnfhj0hbP4Lw==' ? 'M' : 'W';
						// measureDt['age'] = patientDt['dob'];
						dt['age'] = '27';
						if (measureDt != undefined) {
							dt['measureDevice'] = measureDt['measureDevice'];
							dt['measureType'] = measureDt['measureType'];
							dt['measureUtcDt'] = measureDt['measureUtcDt'];
							dt['directInputYn'] = measureDt['directInputYn'];
							dt['measureValue'] =
								measureDt['measureValue1'] +
								(measureDt['measureValue2'] === null ? '' : '/' + measureDt['measureValue2']) +
								(measureDt['measureValue3'] === null ? '' : '/' + measureDt['measureValue3']) +
								(measureDt['measureValue4'] === null ? '' : '/' + measureDt['measureValue4']);
						}
					}
				}

				const data = {
					statusCode: 200,
					data: {
						totalCount: d[1],
						data: d[0],
					},
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	getAssessmentList(doctor: any): Observable<any> {
		const doctorSeq = doctor.doctorSeq;

		const query = this.assessmentRepository
			.createQueryBuilder('assessment')
			.select([
				'patient.firstName as firstName',
				'patient.insung_seq as insungSeq',
				'patient.middleName as middleName',
				'patient.lastName as lastName',
				'patient.gender as gender',
				'patient.dob as dob',
				'assessment.input_utc_dt as inputUtcDt',
				'assessment.assess_type as assessType',
			])
			.leftJoin('patient', 'patient', 'assessment.insung_seq = patient.insung_seq')
			.leftJoin(
				'doctor_patient_relation',
				'doctor_patient_relation',
				'assessment.insung_seq = doctor_patient_relation.insung_seq',
			)
			.where('doctor_patient_relation.doctor_seq = :doctor_seq', { doctor_seq: doctorSeq });

		return from(
			Promise.all([query.getRawMany(), query.getCount()]).then((d) => {
				for (let i = 0; i < d[0].length; i++) {
					const dt = d[0][i];
					dt['name'] =
						(dt['firstName'] === null ? '' : dt['firstName']) +
						(dt['middleName'] === null ? '' : ' ' + dt['middleName']) +
						(dt['lastName'] === null ? '' : ' ' + dt['lastName']);
					dt['gender'] = d[0][i]['gender'] === '4qQRuXdxtOOnfhj0hbP4Lw==' ? 'M' : 'W';
					dt['age'] = '27';
				}
				const data = {
					statusCode: 200,
					data: {
						totalCount: d[1],
						data: d[0],
					},
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	getPatientConsultList(body: any): Observable<any> {
		const skip = (body.page_no - 1) * body.page_size;
		const take = body.page_size;
		const insungSeq = body.insungSeq;

		const query = this.appointmentRepository
			.createQueryBuilder('appointment')
			.select([
				'appointment.appoint_seq as appoint_seq',
				'appointment.appoint_dt as appoint_dt',
				'doctor.first_name as doc_first_name',
				'doctor.middle_name as doc_middle_name',
				'doctor.last_name as doc_last_name',
				'patient.first_name as pat_first_name',
				'patient.middle_name as pat_middle_name',
				'patient.last_name as pat_last_name',
				'appointment_participant.insung_seq as insung_seq',
				'video_consultation_master.call_seq as call_seq',
				'video_consultation_master.subjective as subjective',
				'video_consultation_master.objective as objective',
				'video_consultation_master.assessment as assessment',
				'video_consultation_master.plans as plans',
			])
			.addSelect('ROW_NUMBER () OVER (ORDER BY video_consultation_master.callSeq desc) as row_num')
			.innerJoin(
				'appointment_participant',
				'appointment_participant',
				'appointment.appoint_seq = appointment_participant.appoint_seq',
			)
			.innerJoin(
				'video_consultation_master',
				'video_consultation_master',
				'appointment.appoint_seq = video_consultation_master.appoint_seq',
			)
			.innerJoin('patient', 'patient', 'appointment_participant.insung_seq = patient.insung_seq')
			.innerJoin('doctor', 'doctor', 'appointment.doctor_seq = doctor.doctor_seq')
			.where('appointment_participant.insung_seq = :insung_seq', { insung_seq: insungSeq });
		return from(
			Promise.all([query.offset(skip).limit(take).getRawMany(), query.getCount()]).then((d) => {
				const data = {
					totalCount: d[1],
					data: d[0],
				};
				return data;
			}),
		);
	}
	getPatientMeasureList(doctor: any): Observable<any> {
		const doctorSeq = doctor.doctorSeq;
		const query2 = this.measureTotalRepository
			.createQueryBuilder('measures_total')
			.select([
				'measures_total.insung_seq as insungSeq',
				'measures_total.measure_seq as measureSeq',
				'measures_total.measure_type as measureType',
				'measures_total.device_code as deviceCode',
				'measures_total.measure_utc_dt as measureUtcDt',
				'measures_total.input_utc_dt as inputUtcDt',
				'measures_total.direct_input_yn as directInputYn',
				'measures_total.measure_value1 as measureValue1',
				'measures_total.measure_value2 as measureValue2',
				'measures_total.measure_value3 as measureValue3',
				'measures_total.measure_value4 as measureValue4',
				'measures_total.measure_unit1 as measureUnit1',
				'measures_total.measure_unit2 as measureUnit2',
				'measures_total.measure_unit3 as measureUnit3',
				'measures_total.measure_unit4 as measureUnit4',
				'measures_total.measure_unit5 as measureUnit5',
				'measures_total.measure_device as measureDevice',
			])
			.addSelect('ROW_NUMBER () OVER (ORDER BY measures_total.measure_utc_dt desc) as rowNo')
			.leftJoin(
				'doctor_patient_relation',
				'doctor_patient_relation',
				'measures_total.insung_seq = doctor_patient_relation.insung_seq',
			)
			.where('doctor_patient_relation.doctor_seq = :doctor_seq', { doctor_seq: doctorSeq });

		const query = this.patientRepository
			.createQueryBuilder('patient')
			.select([
				'patient.firstName as firstName',
				'patient.middleName as middleName',
				'patient.lastName as lastName',
				'patient.insung_seq as insungSeq',
				'patient.gender as gender',
				'patient.dob as dob',
				'patient.loginId as loginId',
				'"routine" as status',
				'doctorPatientRelations.doctor_seq as doctor_seq',
			])

			.addSelect('ROW_NUMBER () OVER (ORDER BY patient.input_utc_dt desc) as row_num')
			.leftJoin('patient.doctorPatientRelations', 'doctorPatientRelations')
			.where('doctorPatientRelations.doctor_seq = :doctor_seq', { doctor_seq: doctorSeq });

		return from(
			Promise.all([query.getRawMany(), query2.getCount(), query2.getRawMany()]).then((d) => {
				if (d[2].length == 0) {
				} else {
					for (let i = 0; i < d[1]; i++) {
						const patientDt = _.find(d[0], { insungSeq: d[2][i]['insungSeq'] });
						const measureDt = d[2][i];
						measureDt['name'] =
							(patientDt['firstName'] === null ? '' : patientDt['firstName']) +
							(patientDt['middleName'] === null ? '' : ' ' + patientDt['middleName']) +
							(patientDt['lastName'] === null ? '' : ' ' + patientDt['lastName']);
						measureDt['gender'] = patientDt['gender'] === '4qQRuXdxtOOnfhj0hbP4Lw==' ? 'M' : 'W';
						// measureDt['age'] = patientDt['dob'];
						measureDt['age'] = '27';
						measureDt['measureDevice'] = measureDt['measureDevice'];
						measureDt['measureType'] = measureDt['measureType'];
						measureDt['measureDevice'] = measureDt['measureDevice'];
						measureDt['measureUtcDt'] = measureDt['measureUtcDt'];
						measureDt['directInputYn'] = measureDt['directInputYn'];
						measureDt['measureValue'] =
							measureDt['measureValue1'] +
							(measureDt['measureValue2'] === null ? '' : '/' + measureDt['measureValue2']) +
							(measureDt['measureValue3'] === null ? '' : '/' + measureDt['measureValue3']) +
							(measureDt['measureValue4'] === null ? '' : '/' + measureDt['measureValue4']);
					}
				}

				const data = {
					statusCode: 200,
					data: {
						totalCount: d[1],
						data: d[2],
					},
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	getPatientMeasureGraph(body: any): Observable<any> {
		const skip = (body.page_no - 1) * body.page_size;
		const take = body.page_size;
		const insung_seq = body.insung_seq;
		const measure_type = body.measure_type;
		const startDate = body.startDate != undefined ? body.startDate : null;
		const endDate = body.endDate != undefined ? body.endDate : null;

		const query = this.measureTotalRepository
			.createQueryBuilder('measure_total')
			.select([
				'measure_total.measure_type as measure_type',
				'measure_total.measure_value1 as measure_value1',
				'measure_total.measure_value2 as measure_value2',
				'measure_total.measure_value3 as measure_value3',
				'measure_total.measure_value4 as measure_value4',
				'measure_total.measure_value5 as measure_value5',
				'measure_total.measure_unit1 as measure_unit1',
				'measure_total.measure_unit2 as measure_unit2',
				'measure_total.measure_unit3 as measure_unit3',
				'measure_total.measure_unit4 as measure_unit4',
				'measure_total.measure_unit5 as measure_unit5',
				'measure_total.measure_utc_dt as measure_utc_dt',
				'measure_total.measure_device as measure_device',
				'measure_total.measure_etc as measure_etc',
				'measure_total.direct_input_yn as direct_input_yn',
			])
			.where('measure_total.insung_seq = :insung_seq', { insung_seq })
			.andWhere('measure_total.measure_type = :measure_type', { measure_type });

		if (startDate != null && endDate != null) {
			query
				.andWhere('measure_total.measure_utc_dt >= :measure_utc_dt', { measure_utc_dt: startDate })
				.andWhere('measure_total.measure_utc_dt <= :measure_utc_dt', { measure_utc_dt: endDate });
		}
		query.orderBy('measure_total.measure_date');
		return from(
			Promise.all([query.offset(skip).limit(take).getRawMany()]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	getDoctors(): Observable<any> {
		const query = this.doctorRepository.createQueryBuilder('doctor').getRawMany();
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	getAppointmentList(body: any): Observable<any> {
		const skip = (body.page_no - 1) * body.page_size;
		const take = body.page_size;
		const insung_seq = body.insung_seq;
		const startDate = body.startDate != undefined ? body.startDate : null;
		const endDate = body.endDate != undefined ? body.endDate : null;
		const pat_name = body.pat_name != undefined ? body.pat_name : '';
		const query = this.appointmentRepository
			.createQueryBuilder('appointment')
			.select([
				'appointment.appoint_seq as appoint_seq',
				'appointment.appoint_dt as appoint_dt',
				'appointment.start_time as start_time',
				'appointment.end_time as end_time',
				'appointment.agenda as agenda',
				'appointment.insung_seq as insung_seq',
				'patient.first_name as pat_first_name',
				'patient.middle_name as pat_middle_name',
				'patient.last_name as pat_last_name',
				'"routine" AS status',
				'"" AS diagnosis',
			])
			.innerJoin(
				'appointment_participant',
				'appointment_participant',
				'appointment.appoint_seq = appointment_participant.appoint_seq',
			)
			.innerJoin('patient', 'patient', 'appointment_participant.insung_seq = patient.insung_seq')
			.where('appointment_participant.insung_seq = :insung_seq', { insung_seq })
			.andWhere('appointment.appoint_dt >= :appoint_dt', { appoint_dt: startDate })
			.andWhere('appointment.appoint_dt <= :appoint_dt', { appoint_dt: endDate })
			.andWhere('patient.firstName like :firstName', { firstName: `%${pat_name}%` })
			.orWhere('patient.middleName like :middleName', { middleName: `%${pat_name}%` })
			.orWhere('patient.lastName like :lastName', { lastName: `%${pat_name}%` });

		return from(
			Promise.all([query.offset(skip).limit(take).getRawMany(), query.getCount()]).then((d) => {
				const data = {
					totalCount: d[1],
					data: d[0],
				};
				return data;
			}),
		);
	}
	getAlarmList(body: any): Observable<any> {
		const login_id = body.login_id;
		const take = body.count;
		const query = this.patientRepository.createQueryBuilder('patient');
		query
			.select([
				'patient.firstName as firstName',
				'patient.middleName as middleName',
				'patient.lastName as lastName',
				'patient.insung_seq as insung_seq',
				'"routine" AS status',
				'"" AS content',
			])
			.innerJoin(
				'doctor_patient_relation',
				'doctor_patient_relation',
				'patient.insung_seq = doctor_patient_relation.insung_seq',
			)
			.where('patient.login_id = :login_id', { login_id })
			.limit(take);
		return from(
			Promise.all([query.getRawMany()]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	getMessageList(doctor: any): Observable<any> {
		const doctor_seq = doctor.doctorSeq;

		const query = this.messageRepository
			.createQueryBuilder('message')
			.select([
				'message.message_seq as messageSeq',
				'message.insung_seq as insung_seq',
				'message.message as message',
				'message.check_yn as checkYn',
				'message.input_utc_dt as inputUtcDt',
				'message.sender_flag as senderFlag',
				'patient.firstName as firstName',
				'patient.insung_seq as insungSeq',
				'patient.gender as gender',
				'patient.dob as dob',
				'patient.middleName as middleName',
				'patient.lastName as lastName',
			])
			.leftJoin('patient', 'patient', 'message.insung_seq = patient.insung_seq')
			.leftJoin(
				'doctor_patient_relation',
				'doctor_patient_relation',
				'message.insung_seq = doctor_patient_relation.insung_seq',
			)
			.where('doctor_patient_relation.doctor_seq = :doctor_seq', { doctor_seq });

		return from(
			Promise.all([query.getRawMany(), query.getCount()]).then((d) => {
				for (let i = 0; i < d[1]; i++) {
					const dt = d[0][i];
					dt['name'] =
						(dt['firstName'] === null ? '' : dt['firstName']) +
						(dt['middleName'] === null ? '' : ' ' + dt['middleName']) +
						(dt['lastName'] === null ? '' : ' ' + dt['lastName']);
					dt['check'] = dt['checkYn'] === 'Y' ? 'Check' : 'Uncheck';
					dt['gender'] = d[0][i]['gender'] === '4qQRuXdxtOOnfhj0hbP4Lw==' ? 'M' : 'W';
					// measureDt['age'] = patientDt['dob'];
					dt['age'] = '27';
				}
				const data = {
					statusCode: 200,
					data: {
						totalCount: d[1],
						data: d[0],
					},
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	addMessage(body: any): Observable<any> {
		const insung_seq = body.insung_seq;
		const doctor_seq = body.doctor_seq;
		const message = body.message;
		const sender_flag = body.sender_flag;

		const newMessage = new Message();

		newMessage.insungSeq = insung_seq;
		newMessage.message = message;
		newMessage.senderFlag = sender_flag;
		newMessage.checkYn = 'N';
		newMessage.inputUtcDt = new Date();
		newMessage.doctorSeq = doctor_seq;
		const query = this.messageRepository.save(newMessage);

		const query2 = this.patientRepository
			.createQueryBuilder('patient')
			.select(['patient.token as token'])
			.where('patient.insung_seq = :insung_seq', { insung_seq })
			.getRawOne();

		return from(
			Promise.all([query, query2]).then((d) => {
				if (!admin.apps.length) {
					admin.initializeApp({
						credential: admin.credential.cert(serviceAccount),
						databaseURL: 'https://hicare-c18c9.firebaseio.com',
					});
				}

				const token = d[1].token;
				if (token) {
					const registrationToken = token;
					const payload = {
						data: {
							type: 'message',
							insung_seq: '' + insung_seq,
						},
						notification: {
							title: 'title',
							body: 'body',
							click_action: 'HANDLE_BREAKING_NEWS',
							sound: 'default',
							badge: '1',
						},
					};

					admin
						.messaging()
						.sendToDevice(registrationToken, payload)
						.then(function (response) {
							console.log('successfully sent messsage', response);
						})
						.catch(function (error) {
							console.log('error sending message: ', error);
						});
				}

				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	addAppointment(body: any): Observable<any> {
		const appointDt = body.appointDt;
		const startTime = body.startTime;
		const endTime = body.endTime;
		const agenda = body.agenda;
		const title = body.tilte;
		const reminderEmail = body.eminderEmail;
		const reminderSms = body.eminderSms;
		const inputUtcDt = new Date();
		const appointUtcDt = body.appointUtcDt;
		const timezoneOffset = body.timezoneOffset;

		const newAppointment = new Appointment();

		newAppointment.appointDt = appointDt;
		newAppointment.startTime = startTime;
		newAppointment.endTime = endTime;
		newAppointment.agenda = agenda;
		newAppointment.title = title;
		newAppointment.reminderEmail = reminderEmail;
		newAppointment.reminderSms = reminderSms;
		newAppointment.inputUtcDt = inputUtcDt;
		newAppointment.appointUtcDt = appointUtcDt;
		newAppointment.timezoneOffset = timezoneOffset;
		const query = this.appointmentRepository.save(newAppointment);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	updateAppointment(body: any): Observable<any> {
		const appoint_seq = body.appoint_seq;
		const appointDt = body.appointDt;
		const startTime = body.startTime;
		const endTime = body.endTime;
		const agenda = body.agenda;
		const title = body.title;
		const reminderEmail = body.eminderEmail;
		const reminderSms = body.eminderSms;
		const inputUtcDt = new Date();
		const appointUtcDt = body.appointUtcDt;
		const timezoneOffset = body.timezoneOffset;

		const newAppointment = new Appointment();

		newAppointment.appointDt = appointDt;
		newAppointment.startTime = startTime;
		newAppointment.endTime = endTime;
		newAppointment.agenda = agenda;
		newAppointment.title = title;
		newAppointment.reminderEmail = reminderEmail;
		newAppointment.reminderSms = reminderSms;
		newAppointment.inputUtcDt = inputUtcDt;
		newAppointment.appointUtcDt = appointUtcDt;
		newAppointment.timezoneOffset = timezoneOffset;
		const query = this.appointmentRepository.update(appoint_seq, newAppointment);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	deleteAppointment(body: any): Observable<any> {
		const appoint_seq = body.appoint_seq;

		const query = this.appointmentRepository.delete(appoint_seq);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	getAppointment(doctor: any): Observable<any> {
		const doctor_seq = doctor.doctorSeq;
		const fromDt = doctor.fromDt;
		const toDt = doctor.toDt;

		const query = this.appointmentRepository
			.createQueryBuilder('appointment')
			.select([
				'appointment.appoint_seq',
				'appointment.appoint_dt',
				'appointment.start_time',
				'appointment.end_time',
				'appointment.agenda',
				'patient.insung_seq',
				'patient.firstName as firstName',
				'patient.middleName as middleName',
				'patient.lastName as lastName',
				'"routine" AS status',
				'"" AS diagnosis',
			])
			.innerJoin(
				'appointment_participant',
				'appointment_participant',
				'appointment.appoint_seq = appointment_participant.appoint_seq',
			)
			.innerJoin('patient', 'patient', 'appointment_participant.insung_seq = patient.insung_seq')
			.where('appointment.doctor_seq = :doctor_seq', { doctor_seq })
			.andWhere('appointment.appoint_dt >= :fromDt')
			.andWhere('appointment.appoint_dt <= :toDt')
			.setParameter('fromDt', fromDt)
			.setParameter('toDt', toDt)
			.getRawMany();

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	addSubscribeInfo(body: any): Observable<any> {
		const doctorSeq = body.doctorSeq;
		const pushEndpoint = body.pushEndpoint;
		const pushP256dh = body.pushP256dh;
		const pushAuth = body.pushAuth;

		const newDoctorSubscription = new DoctorSubscription();

		newDoctorSubscription.doctorSeq = doctorSeq;
		newDoctorSubscription.pushEndpoint = pushEndpoint;
		newDoctorSubscription.pushP256dh = pushP256dh;
		newDoctorSubscription.pushAuth = pushAuth;
		newDoctorSubscription.inputUtcDt = new Date();
		const query = this.doctorSubscriptionRepository.save(newDoctorSubscription);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	updateSubscribeInfo(body: any): Observable<any> {
		const doctorSeq = body.doctorSeq;
		const pushEndpoint = body.pushEndpoint;
		const pushP256dh = body.pushP256dh;
		const pushAuth = body.pushAuth;

		const newDoctorSubscription = new DoctorSubscription();

		newDoctorSubscription.doctorSeq = doctorSeq;
		newDoctorSubscription.pushEndpoint = pushEndpoint;
		newDoctorSubscription.pushP256dh = pushP256dh;
		newDoctorSubscription.pushAuth = pushAuth;
		newDoctorSubscription.inputUtcDt = new Date();
		const query = this.doctorSubscriptionRepository.update(doctorSeq, newDoctorSubscription);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	deleteSubscribeInfo(body: any): Observable<any> {
		const doctorSeq = body.doctorSeq;

		const query = this.doctorSubscriptionRepository.delete(doctorSeq);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	getSubscribeInfo(body: any): Observable<any> {
		const doctorSeq = body.doctorSeq;

		return from(
			this.doctorSubscriptionRepository
				.createQueryBuilder('doctorSubscription')
				.select(['doctorSubscription.push_endpoint', 'doctorSubscription.push_p256dh', 'doctorSubscription.push_auth'])
				.where('doctorSubscription.doctor_seq = :doctor_seq', { doctor_seq: doctorSeq })
				.getRawMany()
				.then((d) => {
					const data = {
						data: d[0],
					};
					return data;
				}),
		);
	}
	addDoctorNote(body: any): Observable<any> {
		const subjective = body.subjective;
		const objective = body.objective;
		const assessment = body.assessment;
		const plans = body.plans;
		const newVideoConsultationMaster = new VideoConsultationMaster();

		newVideoConsultationMaster.subjective = subjective;
		newVideoConsultationMaster.objective = objective;
		newVideoConsultationMaster.assessment = assessment;
		newVideoConsultationMaster.plans = plans;
		newVideoConsultationMaster.noteUtcDt = new Date();
		const query = this.videoRepository.save(newVideoConsultationMaster);

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: {
						data: d[0],
					},
					message: 'success',
				};
				return data;
			}),
		);
	}
	updateVideocall(body: any): Observable<any> {
		const callSeq = body.callSeq;
		const callFlag = body.callFlag;

		const newVideoConsultationHistory = new VideoConsultationHistory();
		if (callFlag == 'A') {
			newVideoConsultationHistory.acceptUtcDt = new Date();
		} else {
			newVideoConsultationHistory.endUtcDt = new Date();
		}
		const query = this.videoHistoryRepository.update(callSeq, newVideoConsultationHistory);

		return from(
			Promise.all([query]).then((d) => {
				return d;
			}),
		);
	}
	getVideocallInfo(body: any): Observable<any> {
		const call_seq = body.call_seq;

		return from(
			this.videoRepository
				.createQueryBuilder('videoConsultationMaster')
				.select([
					'videoConsultationMaster.callSeq',
					'videoConsultationMaster.insungSeq',
					'videoConsultationMaster.sessionId',
					'patient.firstName as firstName',
					'patient.middleName as middleName',
					'patient.lastName as lastName',
					'videoConsultationHistory.start_utc_dt',
					'videoConsultationHistory.accept_utc_dt',
					'videoConsultationHistory.end_utc_dt',
					'videoConsultationHistory.flag',
				])
				.innerJoin(
					'video_consultation_history',
					'videoConsultationHistory',
					'videoConsultationMaster.call_seq = videoConsultationHistory.call_seq',
				)
				.innerJoin('patient', 'patient', 'videoConsultationHistory.insung_seq = patient.insung_seq')
				.where('videoConsultationMaster.call_seq = :call_seq', { call_seq })
				.getRawMany()
				.then((d) => {
					return d;
				}),
		);
	}
	initVideocall(body: any): Observable<any> {
		const doctor_seq = body.doctor_seq;

		const query = this.doctorSubscriptionRepository.delete(doctor_seq);

		return from(
			Promise.all([query]).then((d) => {
				return d;
			}),
		);
	}
}
