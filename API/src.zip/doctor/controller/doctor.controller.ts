import {
	Controller,
	Get,
	UseGuards,
	HttpStatus,
	Res,
	Req,
	Post,
	Put,
	Delete,
	Patch,
	Body,
	Query,
} from '@nestjs/common';
import { DoctorService } from '../services/doctor.service';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { JwtAuthGuard } from 'src/auth/guards/jwt-guard';
import { RefreshToken } from 'src/auth/guards/refresh-token';
import { ConfigService } from '@nestjs/config';
import { Response, Request } from 'express';
import { ApiTags, ApiForbiddenResponse, ApiCreatedResponse, ApiBody } from '@nestjs/swagger';
import { DoctorI } from 'src/models/interface/Doctor.interface';
import { AuthService } from 'src/auth/services/auth.service';

@ApiTags('Doctor')
@Controller('doctor')
export class DoctorController {
	constructor(
		private doctorService: DoctorService,
		private configService: ConfigService,
		private authService: AuthService,
	) {}
	public currentDate = new Date();

	@Post('/login')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	loginDoctor(@Body() doctor: DoctorI, @Req() req: Request, @Res() res: Response): Observable<unknown> {
		return this.doctorService.loginDoctor(doctor).pipe(
			map((jwt: string) => {
				return res.status(HttpStatus.OK).json({
					jwt: jwt,
				});
			}),
		);
	}

	@Get('/getPatientList')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getPatientList(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getPatientList(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getPatientMeasureList')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getPatientMeasureList(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getPatientMeasureList(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}
	@Get('/getAssessmentList')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getAssessmentList(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getAssessmentList(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getPatientConsultList')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getPatientConsultList(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getPatientConsultList(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getPatientMeasureGraph')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getPatientMeasureGraph(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getPatientMeasureGraph(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getDoctors')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getDoctors(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getDoctors().pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getAppointmentList')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getAppointmentList(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getAppointmentList(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getAlarmList')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getAlarmList(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getAlarmList(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getMessageList')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getMessageList(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getMessageList(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Put('/addMessage')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addMessage(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.addMessage(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Put('/addAppointment')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addAppointment(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.addAppointment(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Put('/updateAppointment')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateAppointment(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.updateAppointment(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Delete('/deleteAppointment')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	deleteAppointment(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.deleteAppointment(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getAppointment')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getAppointment(
		@Req() req: Request,
		@Res() res: Response,
		@Query('fromDt') fromDt: string,
		@Query('toDt') toDt: string,
	): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		docInfo.fromDt = fromDt;
		docInfo.toDt = toDt;
		return this.doctorService.getAppointment(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Put('/addSubscribeInfo')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addSubscribeInfo(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.addSubscribeInfo(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Put('/updateSubscribeInfo')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateSubscribeInfo(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.updateSubscribeInfo(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Delete('/deleteSubscribeInfo')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	deleteSubscribeInfo(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.deleteSubscribeInfo(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Get('/getSubscribeInfo')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getSubscribeInfo(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getSubscribeInfo(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Put('/addDoctorNote')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addDoctorNote(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.addDoctorNote(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@Put('/updateVideocall')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateVideocall(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.updateVideocall(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	@UseGuards(JwtAuthGuard, RefreshToken)
	@Get('/getVideocallInfo')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getVideocallInfo(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const jwttoken = req?.headers.authorization;
		const TokenArray = jwttoken.split(' ');
		const docInfo = this.authService.decodeJwt(TokenArray[1]).jwt;
		return this.doctorService.getVideocallInfo(docInfo).pipe(
			map((data: any) => {
				return res.status(HttpStatus.OK).json(data);
			}),
		);
	}

	encryptData(data: any, @Req() req: Request): string {
		// Encrypt
		const ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), req?.rawHeaders[1].split(' ')[1]).toString();
		//Decrypt
		const bytes = CryptoJS.AES.decrypt(ciphertext, req?.rawHeaders[1].split(' ')[1]);

		const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));

		return ciphertext;
	}
}
