import { Module } from '@nestjs/common';
import { LogService } from './service/log.service';
import { ApiLogHistory } from '../models/entities/ApiLogHistory';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
	imports: [TypeOrmModule.forFeature([ApiLogHistory])],
	providers: [LogService],
	exports: [LogService],
})
export class LogModule {}
