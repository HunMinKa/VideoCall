import { Injectable, HttpStatus } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { ApiLogHistory } from '../../models/entities/ApiLogHistory';
import { Repository } from 'typeorm';
import { Observable, from, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Response, Request } from 'express';

@Injectable()
export class LogService {
	constructor(
		@InjectRepository(ApiLogHistory) private readonly logRepository: Repository<ApiLogHistory>,
		private configService: ConfigService,
	) {}

	create(d: any): Observable<any> {
		const newLog = new ApiLogHistory();

		newLog.requestKey = d.requestKey;
		newLog.requestHeader = d.requestHeader;
		newLog.requestBody = d.requestBody;
		newLog.requestDate = d.requestDate;
		newLog.responseKey = d.responseKey;
		newLog.responseHeader = d.responseHeader;
		newLog.responseBody = d.responseBody;
		newLog.responseDate = d.responseDate;
		newLog.inputUtcDt = d.requestDate;
		console.log(newLog);

		return from(this.logRepository.save(newLog)).pipe(
			map((log) => {
				const { ...result } = log;
				return result;
			}),
			catchError((err) => throwError(err)),
		);
	}

	getData(req: Request, res: Response, req_body: any, extra: any): Observable<any> {
		const newLog = new ApiLogHistory();

		const reqest_header = {
			'Method:': req?.method,
			RequestUri: req?.url,
			Headers: req?.headers,
		};
		const response_header = {
			'statusCode:': res.status(HttpStatus.OK)?.statusCode,
		};

		newLog.requestKey = req?.rawHeaders[1].split(' ')[1];
		newLog.requestHeader = JSON.stringify(reqest_header);
		newLog.requestBody = JSON.stringify(req_body);
		newLog.requestDate = extra.request_date;
		newLog.responseKey = req?.rawHeaders[1].split(' ')[1];
		newLog.responseHeader = JSON.stringify(response_header);
		newLog.responseBody = extra.value;
		newLog.responseDate = new Date();
		newLog.inputUtcDt = extra.request_date;
		console.log(newLog);
		return from(this.logRepository.save(newLog)).pipe(
			map((log) => {
				const { ...result } = log;
				return result;
			}),
			catchError((err) => throwError(err)),
		);
	}
}
