import { MiddlewareConsumer, Module, NestModule, RequestMethod, Response } from '@nestjs/common';
import { LoginService } from './service/login.service';
import { LoginController } from './controller/login.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Patient } from '../models/entities/Patient';
import { Doctor } from '../models/entities/Doctor';
import { DoctorLogHistory } from '../models/entities/DoctorLogHistory';
import { DoctorPatientRelation } from '../models/entities/DoctorPatientRelation';
import { PatientLogHistory } from '../models/entities/PatientLogHistory';
import { DoctorSubscription } from '../models/entities/DoctorSubscription';
import { MeasureTotal } from '../models/entities/MeasureTotal';
import { Admin } from '../models/entities/Admin';
import { AuthModule } from 'src/auth/auth.module';
import { ApiLogHistory } from '../models/entities/ApiLogHistory';
import { DecrtptyMiddleware, DecrtpytAESMiddleware } from 'src/middleware/enc.middleware';
@Module({
	imports: [
		TypeOrmModule.forFeature([
			Admin,
			Patient,
			PatientLogHistory,
			Doctor,
			DoctorLogHistory,
			DoctorPatientRelation,
			DoctorSubscription,
			MeasureTotal,
			ApiLogHistory,
		]),
		AuthModule,
	],
	providers: [LoginService],
	controllers: [LoginController],
	exports: [LoginService],
})
export class LoginModule implements NestModule {
	configure(consumer: MiddlewareConsumer) {
		consumer.apply(DecrtptyMiddleware).forRoutes({ path: 'login/*', method: RequestMethod.POST });
	}
}
