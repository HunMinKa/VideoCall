import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Patient } from '../../models/entities/Patient';
import { PatientI } from '../../models/interface/Patient.interface';
import { Doctor } from '../../models/entities/Doctor';
import { DoctorI } from '../../models/interface/Doctor.interface';
import { PatientLogHistory } from '../../models/entities/PatientLogHistory';
import { Repository } from 'typeorm';
import { Observable, from } from 'rxjs';
import { AuthService } from 'src/auth/services/auth.service';
import { ConfigService } from '@nestjs/config';
import { switchMap, map } from 'rxjs/operators';
import NodeRSA from 'node-rsa';
import * as crypto from 'crypto';
import * as pkcs7 from 'pkcs7';

import * as admin from 'firebase-admin';
import serviceAccount from '../../hicare-c18c9-firebase-adminsdk-wmvwh-3a9d6cbe99.json';
@Injectable()
export class LoginService {
	constructor(
		@InjectRepository(Patient) private readonly PatientRepository: Repository<Patient>,
		@InjectRepository(Doctor) private readonly DoctorRepository: Repository<Doctor>,
		@InjectRepository(PatientLogHistory) private readonly PatientLogHistoryRepository: Repository<PatientLogHistory>,
		private authService: AuthService,
		private configService: ConfigService,
	) {}
	nowDate = new Date();

	loginPatient(body: any): Observable<any> {
		return this.validatePatient(body.loginId, body.password).pipe(
			switchMap((patient: PatientI) => {
				if (patient) {
					let status = 0;
					let symKey;
					const newPatient = new Patient();
					if (body.symKey != '') {
						symKey = body.symKey;
					} else {
						symKey = patient.symKey;
					}
					newPatient.symKey = symKey;
					newPatient.uuid = patient.uuid;
					if (body.uuidUpdateYn != '') {
						if (body.uuid == '') {
							status = 0;
						} else {
							if (patient.uuid == body.uuid) {
								status = 1;
							} else {
								status = 0;
							}
						}
					} else {
						status = 0;
					}

					const json = {
						insungSeq: patient.insungSeq,
						firstName: patient.firstName,
						middleName: patient.middleName,
						lastName: patient.lastName,
						dob: this.decryptAES(this.configService.get('DOBGENDER'), patient.dob),
						gender: this.decryptAES(this.configService.get('DOBGENDER'), patient.gender),
						loginId: patient.loginId,
						status: status,
					};

					const newPatientLogHistory = new PatientLogHistory();
					newPatientLogHistory.insungSeq = patient.insungSeq;
					newPatientLogHistory.deviceId = patient.loginId;
					newPatientLogHistory.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
					newPatientLogHistory.osVersion = body.osVersion;
					return from(
						Promise.all([
							this.PatientRepository.update(patient.insungSeq, newPatient),
							this.PatientLogHistoryRepository.save(newPatientLogHistory),
						]).then((d) => {
							const data = {
								statusCode: 200,
								data: json,
								message: 'success',
							};

							return data;
						}),
					);
				} else {
					return 'Wrong Credentials';
				}
			}),
		);
	}

	loginPatientQRCode(body: any): Observable<any> {
		return from(
			this.PatientRepository.findOne({
				where: [{ loginId: body.loginId }],
			}),
		).pipe(
			switchMap((patient: PatientI) => {
				if (patient) {
					let status = 0;
					let symKey;
					const newPatient = new Patient();
					if (body.symKey != '') {
						symKey = body.symKey;
					} else {
						symKey = patient.symKey;
					}
					newPatient.symKey = symKey;
					newPatient.uuid = patient.uuid;
					if (body.uuidUpdateYn != '') {
						if (body.uuid == '') {
							status = 0;
						} else {
							if (patient.uuid == body.uuid) {
								status = 1;
							} else {
								status = 0;
							}
						}
					} else {
						status = 0;
					}
					const json = {
						insungSeq: patient.insungSeq,
						firstName: patient.firstName,
						middleName: patient.middleName,
						lastName: patient.lastName,
						dob: this.decryptAES(this.configService.get('DOBGENDER'), patient.dob),
						gender: this.decryptAES(this.configService.get('DOBGENDER'), patient.gender),
						loginId: patient.loginId,
						status: status,
					};

					const newPatientLogHistory = new PatientLogHistory();
					newPatientLogHistory.insungSeq = patient.insungSeq;
					newPatientLogHistory.deviceId = patient.loginId;
					newPatientLogHistory.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
					newPatientLogHistory.osVersion = body.osVersion;
					return from(
						Promise.all([
							this.PatientRepository.update(patient.insungSeq, newPatient),
							this.PatientLogHistoryRepository.save(newPatientLogHistory),
						]).then((d) => {
							const data = {
								statusCode: 200,
								data: json,
								message: 'success',
							};

							return data;
						}),
					);
				} else {
					return 'Wrong Credentials';
				}
			}),
		);
	}

	loginAutoPatient(body: any): Observable<any> {
		// const encryptKey = new NodeRSA(this.configService.get('PUBLIC_KEY'));
		// const encrypted = encryptKey.encrypt(patient, 'base64');

		return from(
			this.PatientRepository.findOne({
				where: [{ insungSeq: body.insungSeq, uuid: body.uuid }],
			}),
		).pipe(
			switchMap((patient: PatientI) => {
				if (patient) {
					let status = 0;
					let symKey;
					const newPatient = new Patient();
					if (body.symKey != '') {
						symKey = body.symKey;
					} else {
						symKey = patient.symKey;
					}
					newPatient.symKey = symKey;
					newPatient.uuid = patient.uuid;
					if (body.uuidUpdateYn != '') {
						if (body.uuid == '') {
							status = 0;
						} else {
							if (patient.uuid == body.uuid) {
								status = 1;
							} else {
								status = 0;
							}
						}
					} else {
						status = 0;
					}

					const json = {
						insungSeq: patient.insungSeq,
						firstName: patient.firstName,
						middleName: patient.middleName,
						lastName: patient.lastName,
						dob: this.decryptAES(this.configService.get('DOBGENDER'), patient.dob),
						gender: this.decryptAES(this.configService.get('DOBGENDER'), patient.gender),
						loginId: patient.loginId,
						status: status,
					};

					const newPatientLogHistory = new PatientLogHistory();
					newPatientLogHistory.insungSeq = patient.insungSeq;
					newPatientLogHistory.deviceId = patient.loginId;
					newPatientLogHistory.inputUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
					newPatientLogHistory.osVersion = body.osVersion;
					return from(
						Promise.all([
							this.PatientRepository.update(patient.insungSeq, newPatient),
							this.PatientLogHistoryRepository.save(newPatientLogHistory),
						]).then((d) => {
							const data = {
								statusCode: 200,
								data: json,
								message: 'success',
							};

							return data;
						}),
					);
				} else {
					return 'Wrong Credentials';
				}
			}),
		);
	}

	loginOutPatient(insungSeq: string): Observable<any> {
		const newPatientLogHistory = new PatientLogHistory();

		newPatientLogHistory.logoutUtcDt = new Date(this.nowDate.getTime() + this.nowDate.getTimezoneOffset() * 60000);
		return from(
			Promise.all([this.PatientLogHistoryRepository.update(insungSeq, newPatientLogHistory)]).then((d) => {
				const data = {
					statusCode: 200,
					data: d[0],
					message: 'success',
				};
				return data;
			}),
		);
	}

	validatePatient(loginId: string, password: string): Observable<PatientI> {
		return from(
			this.PatientRepository.findOne({
				where: [{ loginId: loginId }],
			}),
		).pipe(
			switchMap((patient: PatientI) =>
				this.authService.comparePasswords(password, patient.password).pipe(
					map((match: any) => {
						if (match) {
							const { ...result } = patient;
							return result;
						} else {
							throw Error;
						}
					}),
				),
			),
		);
	}

	loginDoctor(doctor: DoctorI): Observable<string> {
		const encryptKey = new NodeRSA(this.configService.get('PUBLIC_KEY'));
		const encrypted = encryptKey.encrypt(doctor, 'base64');

		const decryptKey = new NodeRSA(this.configService.get('PRIVATE_KEY'));
		const decrypted = JSON.parse(decryptKey.decrypt(encrypted, 'utf8'));
		return this.validateDoctor(decrypted.login_id, decrypted.password).pipe(
			switchMap((doctor: DoctorI) => {
				if (doctor) {
					delete decrypted.password;
					return this.authService.generateJWT(decrypted).pipe(map((jwt: string) => jwt));
				} else {
					return 'Wrong Credentials';
				}
			}),
		);
	}

	validateDoctor(login_id: string, password: string): Observable<any> {
		return from(
			this.DoctorRepository.findOne({
				where: [{ loginId: login_id }],
			}),
		).pipe(
			switchMap((doctor: any) =>
				this.authService.comparePasswords(password, doctor.password).pipe(
					map((match: any) => {
						if (match) {
							const { ...result } = doctor;
							return result;
						} else {
							throw Error;
						}
					}),
				),
			),
		);
	}

	decryptAES(symKey: any, text: any): string {
		const iv = crypto.createHash('md5').update(symKey).digest();
		const decipher = crypto.createDecipheriv('AES-256-CBC', symKey, iv);
		decipher.setAutoPadding(false);
		let decrypted = decipher.update(text, 'base64', 'utf8');
		decrypted += decipher.final('utf8');
		return this.pkcs7Unpad(decrypted);
	}

	pkcs7Unpad(params: any): string {
		const buffer = Buffer.from(params, 'utf8');
		const bytes = new Uint8Array(buffer.length);
		let i = buffer.length;
		while (i--) {
			bytes[i] = buffer[i];
		}
		const result = Buffer.from(pkcs7.unpad(bytes));
		return result.toString('utf8');
	}
}
