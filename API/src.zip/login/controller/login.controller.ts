import {
	Controller,
	Post,
	Body,
	HttpStatus,
	Res,
	Req,
	Session,
	Get,
	UseInterceptors,
	Param,
	UseFilters,
	Put,
} from '@nestjs/common';
import { LoginService } from '../service/login.service';
import { PatientI } from '../../models/interface/Patient.interface';
import { DoctorI } from '../../models/interface/Doctor.interface';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ConfigService } from '@nestjs/config';
import { Response, Request } from 'express';
import { ApiForbiddenResponse, ApiCreatedResponse, ApiTags, ApiBody } from '@nestjs/swagger';
import * as crypto from 'crypto';
import { Base64 } from 'js-base64';
import * as pkcs7 from 'pkcs7';
import { Encryptnterceptor } from 'src/Interceptors/enc.Interceptors';
import * as apiBody from '../../models/interface/PatientAPI';
import { AllExceptionsFilter } from 'src/Exception/exception';
@ApiTags('Login')
@UseInterceptors(Encryptnterceptor)
@Controller('login')
export class LoginController {
	constructor(private loginService: LoginService, private configService: ConfigService) {}

	public currentDate = new Date();

	@Get('/keypair')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getKeypairs(
		@Body() body: any,
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): any {
		const json = {
			publicKey: this.configService.get('PUBLIC_KEY_XML'),
			exponent: this.configService.get('EXPONENT'),
			pemKey: this.configService.get('PUBLIC_KEY'),
		};
		const data = {
			statusCode: 200,
			data: json,
			message: 'success',
		};
		return res.status(HttpStatus.OK).json(data);
	}

	@Post('/patient')
	@UseFilters(new AllExceptionsFilter())
	@ApiBody({ type: apiBody.Login })
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	loginPatient(
		@Body() body: any,
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		let loginW;
		if (body.flag == 'qrcode') {
			loginW = this.loginService.loginPatientQRCode(body);
		} else {
			loginW = this.loginService.loginPatient(body);
		}
		return loginW;
	}

	@Post('/patient/auto-login')
	@ApiBody({ type: apiBody.Autologin })
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	loginAutoPatient(
		@Body() body: any,
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
	): Observable<unknown> {
		return this.loginService.loginAutoPatient(body);
	}

	@Put('/patient/:insungSeq/logout')
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	loginOutPatient(
		@Body() body: any,
		@Req() req: Request,
		@Res() res: Response,
		@Session() session: Record<string, any>,
		@Param('insungSeq') insungSeq: string,
	): Observable<unknown> {
		console.log(insungSeq);
		return this.loginService.loginOutPatient(insungSeq);
	}

	// @Post('/doctor')
	// @ApiCreatedResponse({ description: 'Success' })
	// @ApiForbiddenResponse({ description: 'Forbidden' })
	// loginSession(@Body() doctor: DoctorI, @Req() req: Request, @Res() res: Response): any {
	// 	return res.status(HttpStatus.OK).json({
	// 		access_token: '11',
	// 	});
	// }
}
