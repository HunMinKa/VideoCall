import { existsSync, mkdirSync } from 'fs';
import { diskStorage } from 'multer';
import * as fs from 'fs';
import * as path from 'path';

export const multerOptions = {
	fileFilter: (request, file, callback) => {
		callback(null, true);
	},

	storage: diskStorage({
		destination: (request, file, callback) => {
			const uploadPath = __dirname + '/images';
			if (!existsSync(uploadPath)) {
				// public 폴더가 존재하지 않을시, 생성합니다.
				mkdirSync(uploadPath);
			}
			callback(null, uploadPath);
		},
		filename: (request, file, callback) => {
			callback(null, file.originalname);
		},
	}),
};
