import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Observable, from } from 'rxjs';

import * as CryptoJS from 'crypto-js';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const bcrypt = require('bcryptjs');

@Injectable()
export class AuthService {
	constructor(private readonly jwtService: JwtService) {}

	generateJWT(jwt: any): Observable<string> {
		return from(this.jwtService.signAsync({ jwt }));
	}

	hashPassword(password: string): Observable<string> {
		return from<string>(bcrypt.hash(password, 12));
	}

	decodeJwt(jwt: string): any {
		return this.jwtService.decode(jwt);
	}

	comparePasswords(newPassword: string, passwortHash: string): Observable<any> {
		const result = new Promise((resolve, reject) => {
			const newPwd = CryptoJS.PBKDF2(newPassword, '100000.+hjY4OxRR3gVFiZg06uP1RodTHT6Bn4U94ICdABAKTg=', {
				keySize: 16,
				iterations: 1000,
			}).toString(CryptoJS.enc.Base64);

			if (newPwd == passwortHash) {
				resolve(true);
			} else {
				reject(false);
			}
		});

		return from<any>(result);
	}
}
