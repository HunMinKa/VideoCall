import { Injectable, CanActivate, ExecutionContext, Inject, forwardRef } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { LoginService } from 'src/login/service/login.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from 'src/auth/services/auth.service';

@Injectable()
export class RolesGuard implements CanActivate {
	constructor(
		private reflector: Reflector,

		@Inject(forwardRef(() => LoginService))
		private loginService: LoginService,
		private authService: AuthService,
	) {}

	canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
		const req = context.switchToHttp().getRequest();
		const res = context.switchToHttp().getResponse();

		return this.authService.generateJWT(req.admin).pipe(
			map((jwt: string) => {
				res.cookie('access_token', jwt, {
					secure: true,
				});
				return true;
			}),
		);
	}
}
