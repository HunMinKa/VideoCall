import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from 'src/auth/services/auth.service';
import * as atob from 'atob';
@Injectable()
export class RefreshToken implements CanActivate {
	constructor(private reflector: Reflector, private authService: AuthService) {}

	canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
		const req = context.switchToHttp().getRequest();
		const res = context.switchToHttp().getResponse();

		try {
			const access_token = req?.rawHeaders[1].split(' ')[1];
			const base64Url = access_token?.split('.')[1];
			const base64 = base64Url.replace('-', '+').replace('_', '/');
			const payload = JSON.parse(atob(base64));

			const exp = new Date((payload.exp - 60) * 1000);
			const currentDate = new Date();

			if (exp <= currentDate) {
				return this.authService.generateJWT(req.admin).pipe(
					map((jwt: string) => {
						res.cookie('access_token', jwt, {
							secure: true,
							httpOnly: true,
							maxAge: 10000,
						});
						return true;
					}),
				);
			} else {
				return true;
			}
		} catch (e) {
			console.log(e);
			return true;
		}
	}
}
