import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LicenceController } from './controller/licence.controller';
import { LicenceService } from './services/licence.service';
import { HicareLicence } from '../models/entities/HicareLicence';
@Module({
	imports: [TypeOrmModule.forFeature([HicareLicence])],
	providers: [LicenceService],
	controllers: [LicenceController],
	exports: [LicenceService],
})
export class LicenceModule {}
