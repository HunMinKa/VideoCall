import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { AnyCnameRecord } from 'node:dns';
import { from, Observable } from 'rxjs';
import { HicareLicence } from 'src/models/entities/HicareLicence';
import { Repository } from 'typeorm';
import { v1 } from 'uuid';
@Injectable()
export class LicenceService {
	constructor(@InjectRepository(HicareLicence) private readonly LicenceRepository: Repository<HicareLicence>) {}

	getLicenceList(): Observable<any> {
		const query = this.LicenceRepository.find();
		return from(
			Promise.all([query]).then((d) => {
				return d[0];
			}),
		);
	}

	addLicence(d: any): Observable<any> {
		let query = null;
		const newMHicareLicence = new HicareLicence();

		newMHicareLicence.licenceCompanyName = d.licenceCompanyName;
		newMHicareLicence.licenceEmail = d.licenceEmail;
		newMHicareLicence.licenceJwtKey = d.licenceJwtKey;
		newMHicareLicence.licenceManager = d.licenceManager;
		newMHicareLicence.licencePatientNumber = d.licencePatientNumber;
		newMHicareLicence.licenceTelNumber = d.licenceTelNumber;
		newMHicareLicence.licenceExpirationDate = d.licenceExpirationDate;
		newMHicareLicence.licenceInused = d.licenceInused == 'Y' ? 1 : 0;
		newMHicareLicence.licenceIssueDate = d.licenceIssueDate;
		newMHicareLicence.licenceKey = d.licenceKey;

		if (d.licenceUid == undefined) {
			newMHicareLicence.licenceUid = v1();
			query = this.LicenceRepository.save(newMHicareLicence);
		} else {
			query = this.LicenceRepository.update(d.licenceUid, newMHicareLicence);
		}

		return from(
			Promise.all([query]).then((d) => {
				return d[0];
			}),
		);
	}
}
