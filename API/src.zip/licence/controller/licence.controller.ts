import { Controller, Get, Res, Req, Param, HttpStatus, Post } from '@nestjs/common';
import { Observable } from 'rxjs';
import { Response, Request } from 'express';
import { LicenceService } from '../services/licence.service';
import { map } from 'rxjs/operators';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('Licence')
@Controller('licence')
export class LicenceController {
	constructor(private licenceService: LicenceService) {}

	@Get('list')
	getLicenceList(@Req() req: Request, @Res() res: Response, @Param() params): Observable<unknown> {
		return this.licenceService.getLicenceList().pipe(
			map((result: any) => {
				return res.status(HttpStatus.OK).json(result);
			}),
		);
	}

	@Post('list')
	addLicence(@Req() req: Request, @Res() res: Response, @Param() params): Observable<unknown> {
		console.log(req.body);
		return this.licenceService.addLicence(req.body).pipe(
			map((result: any) => {
				return res.status(HttpStatus.OK).json(result);
			}),
		);
	}
}
