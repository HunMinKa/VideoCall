import { MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { PatientService } from './services/patient.service';
import { PatientController } from './controller/patient.controller';
import { Patient } from '../models/entities/Patient';
import { Appointment } from '../models/entities/Appointment';
import { DoctorPatientRelation } from '../models/entities/DoctorPatientRelation';
import { MeasureTotal } from '../models/entities/MeasureTotal';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { Doctor } from '../models/entities/Doctor';
import { Message } from '../models/entities/Message';
import { PatientContactInfo } from '../models/entities/PatientContactInfo';
import { Admin } from '../models/entities/Admin';
import { PatientDeviceSetting } from '../models/entities/PatientDeviceSetting';
import { AppointmentParticipant } from '../models/entities/AppointmentParticipant';
import { Assessment } from '../models/entities/Assessment';
import { DecrtpytAESMiddleware, DecrtptyMiddleware } from 'src/middleware/enc.middleware';
import { ApiLogHistory } from '../models/entities/ApiLogHistory';
@Module({
	imports: [
		TypeOrmModule.forFeature([
			Patient,
			DoctorPatientRelation,
			Appointment,
			MeasureTotal,
			Doctor,
			Message,
			PatientContactInfo,
			Admin,
			PatientDeviceSetting,
			Assessment,
			AppointmentParticipant,
			ApiLogHistory,
		]),
		AuthModule,
	],
	providers: [PatientService],
	controllers: [PatientController],
	exports: [PatientService],
})
export class PatientModule implements NestModule {
	configure(consumer: MiddlewareConsumer) {
		consumer
			.apply(DecrtpytAESMiddleware)
			.forRoutes({ path: 'patient/*', method: RequestMethod.POST })
			.apply(DecrtptyMiddleware)
			.forRoutes({ path: 'patient/:insungSeq/symetric-key', method: RequestMethod.PUT })
			.apply(DecrtpytAESMiddleware)
			.forRoutes({ path: 'patient/:insungSeq/token', method: RequestMethod.PUT })
			.apply(DecrtpytAESMiddleware)
			.forRoutes({ path: 'patient/message/:messageSeq', method: RequestMethod.PUT })
			.apply(DecrtpytAESMiddleware)
			.forRoutes({ path: 'patient/:insungSeq/service-agreement', method: RequestMethod.PUT })
			.apply(DecrtpytAESMiddleware)
			.forRoutes({ path: 'patient/app-setting', method: RequestMethod.PUT })
			.apply(DecrtpytAESMiddleware)
			.forRoutes({ path: 'patient/*', method: RequestMethod.DELETE })
			.apply(DecrtpytAESMiddleware);
	}
}
