import {
	Controller,
	Get,
	Res,
	Req,
	Param,
	Delete,
	Patch,
	Post,
	Session,
	UseInterceptors,
	Put,
	Query,
	UploadedFile,
	Body,
} from '@nestjs/common';
import { PatientService } from '../services/patient.service';
import { Observable } from 'rxjs';
import { Express } from 'express';
import { ConfigService } from '@nestjs/config';
import { Response, Request } from 'express';
import {
	ApiTags,
	ApiForbiddenResponse,
	ApiCreatedResponse,
	ApiResponseMetadata,
	ApiBody,
	ApiProperty,
	ApiResponse,
	ApiHeader,
} from '@nestjs/swagger';

import { Encryptnterceptor } from 'src/Interceptors/enc.Interceptors';
import { FileInterceptor, FilesInterceptor } from '@nestjs/platform-express';
import { Base64 } from 'js-base64';
import * as pkcs7 from 'pkcs7';
import * as crypto from 'crypto-browserify';
import { multerOptions } from 'src/fileUploader/multerOptions';
import * as fs from 'fs';
import * as path from 'path';

import * as apiBody from '../../models/interface/PatientAPI';

@ApiTags('Patient')
@Controller('patient')
@UseInterceptors(Encryptnterceptor)
export class PatientController {
	constructor(private patientService: PatientService, private configService: ConfigService) {}
	public currentDate = new Date();

	@Put(':insungSeq/token')
	@ApiBody({ type: apiBody.Token })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateToken(@Req() req: Request, @Res() res: Response, @Param('insungSeq') insungSeq: string): Observable<unknown> {
		return this.patientService.updateToken(insungSeq, req.body);
	}

	@Put(':insungSeq/symetric-key')
	@ApiBody({ type: apiBody.SymetricKey })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateSymkey(@Req() req: Request, @Res() res: Response, @Param('insungSeq') insungSeq: string): Observable<unknown> {
		return this.patientService.updateSymkey(insungSeq, req.body);
	}

	@Get(':insungSeq/doctor')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getDoctors(@Req() req: Request, @Res() res: Response, @Param('insungSeq') insungSeq: string): Observable<unknown> {
		return this.patientService.getDoctors(insungSeq);
	}

	@Get(':insungSeq/contact-info')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getContactInfo(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
	): Observable<unknown> {
		return this.patientService.getContactInfo(insungSeq);
	}

	@Get(':insungSeq/message')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getMessageList(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
	): Observable<unknown> {
		return this.patientService.getMessageList(insungSeq);
	}

	@Post('message')
	@ApiBody({ type: apiBody.SymetricKey })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addMessage(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		return this.patientService.addMessage(req.body);
	}

	@Delete('message')
	@ApiBody({ type: apiBody.AppointDelete })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	deleteMessage(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		return this.patientService.deleteMessage(req.body);
	}

	@Put('message/:messageSeq')
	@ApiBody({ type: apiBody.Message })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateMessage(
		@Req() req: Request,
		@Res() res: Response,
		@Param('messageSeq') messageSeq: string,
	): Observable<unknown> {
		return this.patientService.updateMessage(messageSeq);
	}

	@Put(':insungSeq/service-agreement')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateSVCAgreement(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
	): Observable<unknown> {
		return this.patientService.updateSVCAgreement(insungSeq);
	}

	@Get(':insungSeq/service-agreement')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getSVCAgreement(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
	): Observable<unknown> {
		return this.patientService.getSVCAgreement(insungSeq);
	}

	@Get(':insungSeq/app-menu-url')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getAppMenuUrl(@Req() req: Request, @Res() res: Response, @Param('insungSeq') insungSeq: string): Observable<unknown> {
		return this.patientService.getAppMenuUrl(insungSeq);
	}

	@Get(':insungSeq/home')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getHomeData(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
		@Query('searchDt') searchDt: string,
		@Query('timezoneOffset') timezoneOffset: string,
	): Observable<unknown> {
		req.body.insungSeq = insungSeq;
		req.body.searchDt = searchDt;
		req.body.timezoneOffset = timezoneOffset;
		console.log(req.body);
		return this.patientService.getHomeData(req.body);
	}

	@Post('profile-image')
	@ApiBody({ type: apiBody.ProfileImage })
	@UseInterceptors(FilesInterceptor('file', null, multerOptions))
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	updateProfileImage(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		const symKey = req['symKey'];
		req.body = this.decryptAES(symKey, req.body.fileInfo);
		fs.readFile(path.join(__dirname, '../../fileUploader/images/' + req.body.profileImage), 'utf8', (error, d) => {
			fs.writeFileSync(
				path.join(__dirname, '../../fileUploader/images/' + req.body.profileImage),
				this.decryptAES2(symKey, d),
			);
		});

		return this.patientService.updateProfileImage(req.body);
	}

	@Put('app-setting')
	@ApiBody({ type: apiBody.AppSetting })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addAppSetting(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		return this.patientService.addAppSetting(req.body);
	}

	@Post('device-setting')
	@ApiBody({ type: apiBody.DeviceSetting })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addDeviceSetting(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
	): Observable<unknown> {
		return this.patientService.addDeviceSetting(req.body);
	}

	@Get(':insungSeq/device-setting')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getDeviceSetting(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
	): Observable<unknown> {
		return this.patientService.getDeviceSetting(insungSeq);
	}

	@Post('/appoint')
	@ApiBody({ type: apiBody.Appoint })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	addAppointment(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		return this.patientService.addAppointment(req.body);
	}

	@Delete('/appoint')
	@ApiBody({ type: apiBody.AppointDelete })
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	deleteAppointment(@Req() req: Request, @Res() res: Response): Observable<unknown> {
		return this.patientService.deleteAppointment(req.body);
	}

	@Get(':insungSeq/appoint')
	@ApiHeader({
		name: 'uuid',
	})
	@ApiHeader({
		name: 'insungseq',
	})
	@ApiCreatedResponse({ description: 'Success' })
	@ApiForbiddenResponse({ description: 'Forbidden' })
	getAppointment(
		@Req() req: Request,
		@Res() res: Response,
		@Param('insungSeq') insungSeq: string,
		@Query('fromDt') fromDt: string,
		@Query('toDt') toDt: string,
	): Observable<unknown> {
		req.body.insungSeq = insungSeq;
		req.body.fromDt = fromDt;
		req.body.toDt = toDt;
		return this.patientService.getAppointment(req.body);
	}

	decryptAES2(symKey: any, text: any): string {
		const key = Base64.atob(symKey);
		const array = Uint8Array.from(key, (b) => b.charCodeAt(0));
		const iv = crypto.createHash('md5').update(array).digest();

		const decipher = crypto.createDecipheriv('aes-256-cbc', array, iv);

		decipher.setAutoPadding(false);
		let decrypted = decipher.update(text, 'base64', 'base64');
		decrypted += decipher.final('base64');

		return decrypted;
	}

	decryptAES(symKey: any, text: any): string {
		const key = Base64.atob(symKey);
		const array = Uint8Array.from(key, (b) => b.charCodeAt(0));
		const iv = crypto.createHash('md5').update(array).digest();

		const decipher = crypto.createDecipheriv('aes-256-cbc', array, iv);

		decipher.setAutoPadding(false);
		let decrypted = decipher.update(text, 'base64', 'utf8');
		decrypted += decipher.final('utf8');
		return this.pkcs7Unpad(decrypted);
	}

	pkcs7Unpad(params: any): string {
		const buffer = Buffer.from(params, 'utf8');
		const bytes = new Uint8Array(buffer.length);
		let i = buffer.length;
		while (i--) {
			bytes[i] = buffer[i];
		}
		const result = Buffer.from(pkcs7.unpad(bytes));
		return result.toString('utf-8') == '' ? '' : JSON.parse(result.toString('utf-8'));
	}
}
