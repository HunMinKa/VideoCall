import { PatientI } from '../../models/interface/Patient.interface';
import { Repository } from 'typeorm';
import { Observable, from } from 'rxjs';

import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Patient } from '../../models/entities/Patient';
import { Appointment } from '../../models/entities/Appointment';
import { MeasureTotal } from '../../models/entities/MeasureTotal';
import { Doctor } from '../../models/entities/Doctor';
import { Message } from '../../models/entities/Message';
import { PatientContactInfo } from '../../models/entities/PatientContactInfo';
import { Admin } from '../../models/entities/Admin';
import { PatientDeviceSetting } from '../../models/entities/PatientDeviceSetting';
import { Assessment } from '../../models/entities/Assessment';
import { AppointmentParticipant } from '../../models/entities/AppointmentParticipant';
import * as _ from 'lodash';
import moment from 'moment';
import { map } from 'rxjs/operators';

@Injectable()
export class PatientService {
	constructor(
		private configService: ConfigService,
		@InjectRepository(Patient) private readonly patientRepository: Repository<PatientI>,
		@InjectRepository(Appointment) private readonly appointmentRepository: Repository<Appointment>,
		@InjectRepository(MeasureTotal) private readonly measureTotalRepository: Repository<MeasureTotal>,
		@InjectRepository(Admin) private readonly adminRepository: Repository<Admin>,
		@InjectRepository(Doctor) private readonly doctorRepository: Repository<Doctor>,
		@InjectRepository(Message) private readonly messageRepository: Repository<Message>,
		@InjectRepository(PatientContactInfo) private readonly patientContactInfoRepository: Repository<PatientContactInfo>,
		@InjectRepository(PatientDeviceSetting)
		private readonly patientDeviceSettingRepository: Repository<PatientDeviceSetting>,
		@InjectRepository(Assessment) private readonly assessmentRepository: Repository<Assessment>,
		@InjectRepository(AppointmentParticipant)
		private readonly appointmentParticipantRepository: Repository<AppointmentParticipant>,
	) {}
	nowDate = new Date();

	findOne(id: number): Observable<PatientI> {
		return from(this.patientRepository.findOne(id)).pipe(
			map((patient: PatientI) => {
				return patient;
			}),
		);
	}

	fileUpload(): any {
		const data = {
			statusCode: 200,
			message: 'success',
		};
		return data;
	}

	updateToken(insungSeq: any, body: any): Observable<any> {
		const token = body.token;
		const newPatient = new Patient();
		newPatient.token = token;
		const query = this.patientRepository.update(insungSeq, newPatient);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	updateSymkey(insungSeq: any, body: any): Observable<any> {
		console.log(body.symKey);
		const symKey = body.symKey;
		const newPatient = new Patient();
		newPatient.symKey = symKey;
		const query = this.patientRepository.update(insungSeq, newPatient);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	getDoctors(insungSeq: any): Observable<any> {
		const query = this.doctorRepository
			.createQueryBuilder('doctor')
			.select([
				'doctor.doctor_seq as doctorSeq',
				'CONCAT(IFNULL(doctor.first_name,""),IFNULL(doctor.middle_name,"") ,IFNULL(doctor.last_name,"")) as doctorName',
				'doctor.role as role',
			])
			.leftJoin(
				'doctor_patient_relation',
				'doctor_patient_relation',
				'doctor.doctor_seq = doctor_patient_relation.doctor_seq',
			)
			.where('doctor_patient_relation.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.getRawMany();
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: d[0],
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	getContactInfo(insungSeq: any): Observable<any> {
		const query = this.patientContactInfoRepository
			.createQueryBuilder('patientContactInfo')
			.select([
				'patientContactInfo.contact_title as contactTitle',
				'patientContactInfo.contact_telnum as contactTelnum',
			])
			.where('patientContactInfo.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.getRawMany();
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: d[0],
					message: 'success',
				};
				return data;
			}),
		);
	}
	getMessageList(insungSeq: any): Observable<any> {
		const query = this.messageRepository
			.createQueryBuilder('message')
			.select([
				'message.message_seq as messageSeq',
				'message.message as message',
				'message.check_yn as checkYn',
				'message.input_utc_dt as inputUtcDt',
				'message.sender_flag as senderFlag',
				'doctor.doctor_seq as doctorSeq',
				'CONCAT(IFNULL(doctor.first_name,""),IFNULL(doctor.middle_name,"") ,IFNULL(doctor.last_name,"")) as doctorName',
			])
			.leftJoin('doctor', 'doctor', 'message.doctor_seq = doctor.doctor_seq')
			.where('message.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.getRawMany();

		return from(
			Promise.all([query]).then((d) => {
				for (let i = 0; i < d[0].length; i++) {
					d[0][i].inputUtcDt = moment(d[0][i].inputUtcDt).format('YYYY-MM-DD HH:mm:ss');
				}
				const data = {
					statusCode: 200,
					data: d[0],
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	addMessage(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const doctorSeq = body.doctorSeq;
		const message = body.message;

		const newMessage = new Message();

		newMessage.insungSeq = insungSeq;
		newMessage.message = message;
		newMessage.senderFlag = 'P';
		newMessage.checkYn = 'N';
		newMessage.inputUtcDt = new Date();
		newMessage.doctorSeq = doctorSeq;
		const query = this.messageRepository.save(newMessage);

		const query2 = this.patientRepository
			.createQueryBuilder('patient')
			.select(['patient.token as token'])
			.where('patient.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.getRawOne();

		return from(
			Promise.all([query, query2]).then(() => {
				// if (!admin.apps.length) {
				// 	admin.initializeApp({
				// 		credential: admin.credential.cert(serviceAccount),
				// 		databaseURL: 'https://hicare-c18c9.firebaseio.com',
				// 	});
				// }

				// const token = d[1].token;
				// if (token) {
				// 	const registrationToken = token;
				// 	const payload = {
				// 		data: {
				// 			type: 'message',
				// 			insung_seq: '' + insungSeq,
				// 		},
				// 		notification: {
				// 			title: 'title',
				// 			body: 'body',
				// 			click_action: 'HANDLE_BREAKING_NEWS',
				// 			sound: 'default',
				// 			badge: '1',
				// 		},
				// 	};

				// 	admin
				// 		.messaging()
				// 		.sendToDevice(registrationToken, payload)
				// 		.then(function (response) {
				// 			console.log('successfully sent messsage', response);
				// 		})
				// 		.catch(function (error) {
				// 			console.log('error sending message: ', error);
				// 		});
				// }
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	deleteMessage(body: any): Observable<any> {
		console.log(body);
		const messageSeq = body;
		const seq = [];
		for (let i = 0; i < messageSeq.length; i++) {
			seq.push(messageSeq[i].messageSeq);
		}
		const query = this.messageRepository.delete(messageSeq);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	updateMessage(messageSeq: any): Observable<any> {
		const newMessage = new Message();
		newMessage.checkYn = 'Y';
		const query = this.messageRepository.update(messageSeq, newMessage);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	updateSVCAgreement(insungSeq: any): Observable<any> {
		const newPatient = new Patient();

		newPatient.svcAgreeYn = 'Y';

		const query = this.patientRepository.update(insungSeq, newPatient);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	getSVCAgreement(insungSeq: any): Observable<any> {
		const query = this.patientRepository
			.createQueryBuilder('patient')
			.select(['patient.svc_agree_yn as serviceAgreeYn'])
			.where('patient.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.getRawMany();
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: d[0][0],
					message: 'success',
				};
				return data;
			}),
		);
	}
	getAppMenuUrl(insungSeq: any): Observable<any> {
		const query = this.adminRepository
			.createQueryBuilder('admins')
			.select(['admins.assess_url as assessUrl', 'admins.education_url as educationUrl'])
			.innerJoin('patient', 'patient', 'admins.admin_seq = patient.admin_seq')
			.where('patient.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.getRawMany();
		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: d[0][0],
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	getHomeData(body: any): Observable<any> {
		const vFromDt = body.searchDt == '' ? '1900-01-01 00:00:00' : body.searchDt + ' 00:00:00';
		const vToDt = body.searchDt == '' ? '9999-12-31 23:59:59' : body.searchDt + ' 23:59:59';
		const timezoneOffset = body.timezoneOffset;

		const query = this.patientRepository
			.createQueryBuilder('patient')
			.select([
				'patient.firstName as firstName',
				'patient.middleName as middleName',
				'patient.lastName as lastName',
				'patient.profile_image as profileImage',
				'patient.session_timeout as sessionTimeOut',
				'patient.turnoff_timeout as turnOffTimeOut',
				'patient.sw_version as softwareVersion',
				'patient.hw_version as hardwareVersion',
			])
			.where('patient.insung_seq = :insung_seq', { insung_seq: body.insungSeq })
			.getRawMany();

		const query2 = this.measureTotalRepository
			.createQueryBuilder('measures_total')
			.select([
				'measures_total.measure_seq as measureSeq',
				'measures_total.measure_type as measureType',
				'measures_total.measure_device as measureModel',
				'measures_total.device_code as deviceCode',
				'measures_total.measure_utc_dt as measureUtcDt',
				'measures_total.input_utc_dt as inputUtcDt',
				'measures_total.measure_value1 as measureValue1',
				'measures_total.measure_value2 as measureValue2',
				'measures_total.measure_value3 as measureValue3',
				'measures_total.measure_value4 as measureValue4',
				'measures_total.measure_unit1 as measureUnit1',
				'measures_total.measure_unit2 as measureUnit2',
				'measures_total.measure_unit3 as measureUnit3',
				'measures_total.measure_unit4 as measureUnit4',
				'measures_total.measure_unit5 as measureUnit5',
				'measures_total.measure_device as measureDevice',
			])
			.where('measures_total.insung_seq = :insung_seq', { insung_seq: body.insungSeq })
			.orderBy('measures_total.measure_date', 'DESC')
			.limit(1)
			.getRawMany();

		const query3 = this.appointmentRepository
			.createQueryBuilder('appointment')
			.select([
				'"appointments" as flag',
				'appointment.start_time as startTime',
				'"" as message',
				'CONCAT(IFNULL(doctor.first_name,""),IFNULL(doctor.middle_name,"") ,IFNULL(doctor.last_name,"")) as doctorName',
				'appointment.appoint_dt as date',
			])
			.innerJoin('doctor', 'doctor', 'appointment.doctor_seq = doctor.doctor_seq')
			.innerJoin(
				'appointment_participant',
				'appointment_participant',
				'appointment.appoint_seq = appointment_participant.appoint_seq',
			)
			.where('appointment_participant.insung_seq = :insung_seq', { insung_seq: body.insungSeq })
			.andWhere('DATE_ADD(appointment.appoint_dt, INTERVAL ' + timezoneOffset + ' MINUTE) > :vFromDt')
			.andWhere('DATE_ADD(appointment.appoint_dt, INTERVAL ' + timezoneOffset + ' MINUTE) < :vToDt')
			.setParameter('vFromDt', vFromDt)
			.setParameter('vToDt', vToDt)
			.getRawMany();

		const query4 = this.messageRepository
			.createQueryBuilder('messages')
			.select([
				'"messages" as flag',
				'"" as startTime',
				'messages.message as message',
				'CONCAT(IFNULL(doctor.first_name,""),IFNULL(doctor.middle_name,"") ,IFNULL(doctor.last_name,"")) as doctorName',
				'"" as date',
			])
			.innerJoin('doctor', 'doctor', 'messages.doctor_seq = doctor.doctor_seq')
			.where('messages.insung_seq = :insung_seq', { insung_seq: body.insungSeq })
			.andWhere('DATE_ADD(messages.input_utc_dt, INTERVAL ' + timezoneOffset + ' MINUTE) > :vFromDt')
			.andWhere('DATE_ADD(messages.input_utc_dt, INTERVAL ' + timezoneOffset + ' MINUTE) < :vToDt')
			.setParameter('vFromDt', vFromDt)
			.setParameter('vToDt', vToDt)
			.getRawMany();

		return from(
			Promise.all([query, query2, query3, query4]).then((d) => {
				const newArr = [...d[2], ...d[3]];

				const data = {
					statusCode: 200,
					data: {
						profile: {
							firstName: d[0][0].firstName,
							middleName: d[0][0].middleName,
							lastName: d[0][0].lastName,
							profileImage: d[0][0].profileImage,
							sessionTimeOut: d[0][0].sessionTimeOut,
							turnOffTimeOut: d[0][0].turnOffTimeOut,
							softwareVersion: d[0][0].softwareVersion,
							hardwareVersion: d[0][0].hardwareVersion,
						},
						recent: {
							measureSeq: d[1][0].measureSeq,
							measureType: d[1][0].measureType,
							measureModel: d[1][0].measureModel,
							deviceCode: d[1][0].deviceCode,
							measureUtcDt: moment(d[1][0]['measureUtcDt']).format('YYYY-MM-DD HH:mm:ss'),
							inputUtcDt: moment(d[1][0]['inputUtcDt']).format('YYYY-MM-DD HH:mm:ss'),
							measureRow: this.SetMeasureValue(d[1][0]),
						},
						today: newArr,
					},
					message: 'success',
				};

				return data;
			}),
		);
	}
	updateProfileImage(body: any): Observable<any> {
		const newPatient = new Patient();

		newPatient.profileImage = body.profileImage;

		const query = this.patientRepository.update(body.insungSeq, newPatient);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	addAppSetting(body: any): Observable<any> {
		//const insungSeq = body.insungSeq;
		const sessionTimeout = body.sessionTimeOut;
		const turnoffTimeout = body.turnOffTimeOut;
		const swVersion = body.softwareVersion;
		const hwVersion = body.hardwareVersion;
		const newPatient = new Patient();
		//newPatient.insungSeq = insungSeq;
		newPatient.sessionTimeout = sessionTimeout;
		newPatient.turnoffTimeout = turnoffTimeout;
		newPatient.swVersion = swVersion;
		newPatient.hwVersion = hwVersion;

		const query = this.patientRepository.update(body.insungSeq, newPatient);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	addDeviceSetting(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const measureType = body.measureType;
		const deviceCode = body.deviceCode;

		const newPatientDeviceSetting = new PatientDeviceSetting();
		newPatientDeviceSetting.insungSeq = insungSeq;
		newPatientDeviceSetting.measureType = measureType;
		newPatientDeviceSetting.deviceCode = deviceCode;
		//newPatientDeviceSetting.inputUtcDt = this.setMeasureUTC(new Date(), -540);
		newPatientDeviceSetting.inputUtcDt = new Date();
		const query = this.patientDeviceSettingRepository.save(newPatientDeviceSetting);
		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	getDeviceSetting(insungSeq: any): Observable<any> {
		const query = this.patientDeviceSettingRepository
			.createQueryBuilder('patientDeviceSetting')
			.select(['patientDeviceSetting.device_code as deviceCode', 'patientDeviceSetting.measure_type as measureType'])
			.where('patientDeviceSetting.insung_seq = :insung_seq', { insung_seq: insungSeq })
			.getRawMany();

		return from(
			Promise.all([query]).then((d) => {
				const data = {
					statusCode: 200,
					data: d[0],
					message: 'success',
				};
				return data;
			}),
		);
	}
	addAppointment(body: any): Observable<any> {
		const doctorSeq = body.doctorSeq;
		const insungSeq = body.insungSeq;
		const appointDt = body.appointDt;
		const startTime = body.startTime;
		const endTime = body.endTime;

		const newAppointment = new Appointment();
		newAppointment.doctorSeq = doctorSeq;
		newAppointment.insungSeq = insungSeq;
		newAppointment.appointDt = appointDt;
		newAppointment.startTime = startTime;
		newAppointment.endTime = endTime;
		newAppointment.confirmYn = 'N';

		const query = this.appointmentRepository.save(newAppointment);

		return from(
			Promise.all([query]).then((d) => {
				const newAppointmentParticipant1 = new AppointmentParticipant();
				newAppointmentParticipant1.appointSeq = d[0].appointSeq;
				newAppointmentParticipant1.insungSeq = insungSeq;

				const newAppointmentParticipant2 = new AppointmentParticipant();
				newAppointmentParticipant1.appointSeq = d[0].appointSeq;
				newAppointmentParticipant1.doctorSeq = doctorSeq;

				this.appointmentParticipantRepository.save(newAppointmentParticipant1);
				this.appointmentParticipantRepository.save(newAppointmentParticipant2);

				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	deleteAppointment(body: any): Observable<any> {
		const appointSeq = body;
		const seq = [];
		for (let i = 0; i < appointSeq.length; i++) {
			seq.push(appointSeq[i].appointSeq);
		}
		const query = this.appointmentRepository.delete(seq);
		return from(
			Promise.all([query]).then((d) => {
				console.log(d);
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	getAppointment(body: any): Observable<any> {
		let fromDt;
		let toDt;
		if (body.fromDt.length < 8) {
			fromDt = body.fromDt + '-01';
			const date = new Date(body.fromDt.split('-')[0], body.fromDt.split('-')[1], 0);
			toDt = body.toDt + '-' + date.getDate();
		} else {
			fromDt = body.fromDt;
			toDt = body.toDt;
		}

		const query = this.appointmentRepository
			.createQueryBuilder('appointment')
			.select([
				'appointment.appoint_seq as appointSeq',
				'appointment.appoint_dt as appointDt',
				'appointment.start_time as startTime',
				'appointment.end_time as endTime',
				'TIMESTAMPDIFF(MINUTE, appointment.start_time, appointment.end_time) as duration',
				'appointment.agenda as agenda',
				'appointment.timezone_offset as timezoneOffset',
				'appointment.appoint_utc_dt as appointUtcDt',
				'appointment.confirm_yn as confirmYn',
				'appointment.confirm_flag as confirmFlag',
			])
			.innerJoin(
				'appointment_participant',
				'appointment_participant',
				'appointment.appoint_seq = appointment_participant.appoint_seq',
			)
			.where('appointment_participant.insung_seq = :insungSeq', { insungSeq: body.insungSeq })
			.andWhere('appointment.appoint_dt >= :fromDt')
			.andWhere('appointment.appoint_dt <= :toDt')
			.setParameter('fromDt', fromDt)
			.setParameter('toDt', toDt)
			.getRawMany();

		const query2 = this.appointmentParticipantRepository
			.createQueryBuilder('appointment_participant')
			.select([
				'appointment_participant.doctor_seq as doctorSeq',
				'appointment_participant.appoint_seq as  appointSeq',
				'"D" as userType',
				'doctor.first_name + doctor.middle_name + doctor.last_name as name',
			])
			.innerJoin('doctor', 'doctor', 'appointment_participant.doctor_seq = doctor.doctor_seq')
			.getRawMany();
		return from(
			Promise.all([query, query2]).then((d) => {
				for (let i = 0; i < d[0].length; i++) {
					d[0][i].appointParticipants = _.find(d[1], function (o) {
						return o.appointSeq == d[0][i].appointSeq;
					});
				}
				const data = {
					statusCode: 200,
					data: d[0],
					message: 'success',
				};
				console.log(data);
				return data;
			}),
		);
	}
	// 필요 요청
	addAssessment(body: any): Observable<any> {
		const insungSeq = body.insungSeq;
		const assessDt = body.assessDt;
		const assessType = body.assessType;
		const answer = body.answer;

		const newAssessment = new Assessment();

		newAssessment.insungSeq = insungSeq;
		newAssessment.assessDt = assessDt;
		newAssessment.assessType = assessType;
		newAssessment.answer = answer;

		const query = this.assessmentRepository.save(newAssessment);

		return from(
			Promise.all([query]).then(() => {
				const data = {
					statusCode: 200,
					message: 'success',
				};
				return data;
			}),
		);
	}
	setMeasureUTC(measureDate, timezoneOffset): any {
		const measureUTC =
			measureDate.substr(0, 4) +
			'-' +
			measureDate.substr(4, 2) +
			'-' +
			measureDate.substr(6, 2) +
			' ' +
			measureDate.substr(8, 2) +
			':' +
			measureDate.substr(10, 2) +
			':' +
			measureDate.substr(12, 2);
		const date = new Date(measureUTC);
		return new Date(date.getTime() + timezoneOffset * 60000);
	}
	SetMeasureValue(d): any {
		let teStatus = 0;
		let row;
		if (d.measureType == 'TE') {
			if (d.measureUnit1 == '℃') {
				teStatus = this.GetMeasureValueStatus('TE', '', d.measureValue1);
			}
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: this.GetMeasureValueStatusColor(teStatus),
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'KE') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'HB') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'BU') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'PH') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: '',
					measureValue: d.measureValue2,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'TC') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (
			d.measureType == 'EC' ||
			d.measureType == 'PF' ||
			d.measureType == 'UR' ||
			d.measureType == 'AS' ||
			d.measureType == 'CO' ||
			d.measureType == 'LM' ||
			d.measureType == 'OT'
		) {
			if (d.measureType == 'EC') {
				row = [
					{
						measureItem: 'bent rate',
						measureValue: d.measureValue1,
						measureUnit: 'bpm',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'pr interval',
						measureValue: d.measureValue2,
						measureUnit: 'ms',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'qrs interval',
						measureValue: d.measureValue3,
						measureUnit: 'ms',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			} else if (d.measureType == 'PF') {
				if (d.measureDevice.toLowerCase() == 'pf200' || d.measureDevice.toLowerCase() == 'asma-1') {
					row = [
						{
							measureItem: 'pef',
							measureValue: d.measureValue1,
							measureUnit: 'L/min',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'fev1',
							measureValue: d.measureValue2,
							measureUnit: 'L',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'qrs interval',
							measureValue: d.measureValue3,
							measureUnit: 'ms',
							measureColor: '',
							measureStatus: teStatus,
						},
					];
				} else {
					row = [
						{
							measureItem: 'fvc',
							measureValue: d.measureValue1,
							measureUnit: 'L',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'fev1',
							measureValue: d.measureValue2,
							measureUnit: 'L',
							measureColor: '',
							measureStatus: teStatus,
						},
						{
							measureItem: 'fev1/fvc',
							measureValue: d.measureValue3,
							measureUnit: '%',
							measureColor: '',
							measureStatus: teStatus,
						},
					];
				}
			} else if (d.measureType == 'AS') {
				row = [
					{
						measureItem: 'pef',
						measureValue: d.measureValue1,
						measureUnit: 'L/min',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev1',
						measureValue: d.measureValue2,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			} else if (d.measureType == 'CO') {
				row = [
					{
						measureItem: 'fev1',
						measureValue: d.measureValue1,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev6',
						measureValue: d.measureValue2,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev1/fev6',
						measureValue: d.measureValue3,
						measureUnit: '%',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			} else if (d.measureType == 'LM') {
				row = [
					{
						measureItem: 'fev1',
						measureValue: d.measureValue1,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev1%',
						measureValue: d.measureValue2,
						measureUnit: '%',
						measureColor: '',
						measureStatus: teStatus,
					},
					{
						measureItem: 'fev6',
						measureValue: d.measureValue3,
						measureUnit: 'L',
						measureColor: '',
						measureStatus: teStatus,
					},
				];
			}
		} else if (d.measureType == 'BP') {
			const sys = this.GetMeasureValueStatus('BP', 'sys', d.measureValue1);
			const dia = this.GetMeasureValueStatus('BP', 'dia', d.measureValue2);
			const pulse = this.GetMeasureValueStatus('PU', '', d.measureValue3);
			let bpColor = '';
			if (sys >= dia) bpColor = this.GetMeasureValueStatusColor(sys);
			else bpColor = this.GetMeasureValueStatusColor(dia);

			const pulseColor = this.GetMeasureValueStatusColor(pulse);

			row = [
				{
					measureItem: 'systolic',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: bpColor,
					measureStatus: teStatus,
				},
				{
					measureItem: 'diastolic',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit1,
					measureColor: bpColor,
					measureStatus: teStatus,
				},
				{
					measureItem: 'pulse',
					measureValue: d.measureValue3,
					measureUnit: 'bpm',
					measureColor: pulseColor,
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'GL' || d.measureType == 'GH') {
			let timeFlag = d.measurevalue2;
			if (timeFlag == '1') timeFlag = 'before meal';
			else if (timeFlag == '2') timeFlag = 'after meal';
			else timeFlag = 'others';

			let glStatus = 0;

			if (d.measureUnit1 == 'mg/dL') {
				glStatus = this.GetMeasureValueStatus('GL', d.measureValue2, d.measureValue1);
			}
			row = [
				{
					measureItem: 'glucose',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: this.GetMeasureValueStatusColor(glStatus),
					measureStatus: teStatus,
				},
			];
			if (d.measureType == 'GH') {
				row.push({
					measureItem: 'hct',
					measureValue: d.measureValue3,
					measureUnit: '%',
					measureColor: '',
					measureStatus: teStatus,
				});
			}
		} else if (d.measureType == 'CH' || d.measureType == 'CA') {
			row = [
				{
					measureItem: 'tc',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'tg',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'hdl',
					measureValue: d.measureValue3,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'ldl',
					measureValue: d.measureValue4,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'tc / hdl',
					measureValue: d.measureValue5,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'WE') {
			row = [
				{
					measureItem: 'weight',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'height',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit2,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bmi',
					measureValue: d.measureValue3,
					measureUnit: d.measureUnit3,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bodyfat',
					measureValue: d.measureValue4,
					measureUnit: d.measureUnit4,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'BM') {
			row = [
				{
					measureItem: 'weight',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'height',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit2,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bmi',
					measureValue: d.measureValue3,
					measureUnit: d.measureUnit3,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'bodyfat',
					measureValue: d.measureValue4,
					measureUnit: d.measureUnit4,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'OX') {
			const puStatus = this.GetMeasureValueStatus('PU', '', d.measureValue2);
			row = [
				{
					measureItem: 'spo2',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'pulse',
					measureValue: d.measureValue2,
					measureUnit: d.measureUnit2,
					measureColor: this.GetMeasureValueStatusColor(puStatus),
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'IN') {
			row = [
				{
					measureItem: 'inr',
					measureValue: d.measureValue1,
					measureUnit: 'INR',
					measureColor: '',
					measureStatus: teStatus,
				},
				{
					measureItem: 'pt',
					measureValue: d.measureValue2,
					measureUnit: 'sec.',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
			if (d.measureValue3 != '' && d.measureDevice == 'CoaguChek XS') {
				row.push({
					measureItem: 'percentq',
					measureValue: d.measureValue3,
					measureUnit: '%Q',
					measureColor: '',
					measureStatus: teStatus,
				});
			}
		} else if (d.measureType == 'MS') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'ME') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'ST') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: '',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'UC') {
			row = [
				{
					measureItem: '',
					measureValue: d.measureValue1,
					measureUnit: d.measureUnit1,
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		} else if (d.measureType == 'CG') {
			row = [
				{
					measureItem: 'etco2',
					measureValue: d.measureValue1,
					measureUnit: '%',
					measureColor: '',
					measureStatus: teStatus,
				},
			];
		}
		return row;
	}
	GetMeasureValueStatus(measureType, subType, measureValue): any {
		let rtnValue = 0;
		const fValue = parseFloat(measureValue);

		if (measureType == 'BP') {
			if (subType == 'sys') {
				if (fValue < 120) rtnValue = 0;
				else if (fValue >= 120 && fValue <= 139) rtnValue = 1;
				else if (fValue >= 140 && fValue <= 159) rtnValue = 2;
				else if (fValue >= 160) rtnValue = 3;
			}

			if (subType == 'dia') {
				if (fValue < 80) rtnValue = 0;
				else if (fValue >= 80 && fValue <= 89) rtnValue = 1;
				else if (fValue >= 90 && fValue < 99) rtnValue = 2;
				else if (fValue >= 100) rtnValue = 3;
			}
		} else if (measureType == 'PU') {
			if (fValue >= 100) rtnValue = 3;
			else rtnValue = 0;
		} else if (measureType == 'GL') {
			if (subType == '0') {
				if (fValue < 100) rtnValue = 0;
				else if (fValue >= 100 && fValue <= 125) rtnValue = 1;
				else if (fValue > 125) rtnValue = 3;
			} else if (subType == '1') {
				if (fValue < 140) rtnValue = 0;
				else if (fValue >= 140 && fValue < 200) rtnValue = 1;
				else if (fValue >= 200) rtnValue = 3;
			} else if (subType == '2') {
				rtnValue = 0;
			}
		} else if (measureType == 'TE') {
			if (fValue >= 36 && fValue <= 37.9) rtnValue = 0;
			else if (fValue >= 38 && fValue < 39.9) rtnValue = 1;
			else if (fValue >= 40 && fValue <= 42) rtnValue = 2;
			else if (fValue > 42) rtnValue = 3;
		}

		return rtnValue;
	}
	GetMeasureValueStatusColor(grade): any {
		let rtnValue = '454545';
		switch (grade) {
			case 0:
				rtnValue = '454545';
				break;
			case 1:
				rtnValue = 'ffc500';
				break;
			case 2:
				rtnValue = 'c06100';
				break;
			case 3:
				rtnValue = 'f10101';
				break;
			default:
				rtnValue = '454545';
				break;
		}
		return rtnValue;
	}
}
